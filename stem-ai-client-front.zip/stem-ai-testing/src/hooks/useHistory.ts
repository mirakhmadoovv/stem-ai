import {
  useMutation,
  useQuery,
  useQueryClient,
  type UseQueryOptions,
} from '@tanstack/react-query'
import type { ApiResponse, HistoryType } from '../api/api.types'
import { getHistoryById, getHistory, deleteHistoryById } from '../api/history'
import { toast } from 'react-toastify'

export const useHistory = (
  options?: UseQueryOptions<ApiResponse<HistoryType>, Error>
) => {
  return useQuery<ApiResponse<HistoryType>, Error>({
    queryKey: ['history'],
    queryFn: () => getHistory(),
    staleTime: 1000 * 60 * 10,
    ...options,
  })
}

export const useHistoryById = (id: number) => {
  return useQuery<HistoryType, Error>({
    queryKey: ['history', id],
    queryFn: () => getHistoryById(id),
    staleTime: 1000 * 60 * 10,
    gcTime: 1000 * 60 * 10,
  })
}

export const useDeleteHistoryById = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: number) => deleteHistoryById(id),
    onSuccess: () => {
      toast.success('История успешно удалена!')
      queryClient.invalidateQueries({
        queryKey: ['history'],
      })
    },
    onError: () => {
      toast.error('Произошла ошибка при удалении истории')
    },
  })
}
