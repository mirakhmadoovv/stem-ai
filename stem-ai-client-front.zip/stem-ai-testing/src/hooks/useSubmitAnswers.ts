import { useMutation } from '@tanstack/react-query'
import apiClient from '../api/axios'
import type { Question, QuestionAnswer } from '../api/api.types'

interface SubmitAnswersRequest {
  project_id: number
  language_id: number
  questions: Array<{
    question_group: number
    question_id: number
    boolean_answer?: boolean
    free_answer?: string
    options?: number[]
  }>
}

interface SubmitAnswersResponse {
  result: string
  prompt_tokens: number
  completion_tokens: number
  total_tokens: number
  total_cost_usd: number
  chat: {
    id: number
    title: string
    created_at: string
    message_id: number
  }
}

const transformAnswersToApiFormat = (
  projectId: number,
  languageId: number,
  answers: Record<number, QuestionAnswer>,
  allQuestions: Question[]
): SubmitAnswersRequest => {
    const apiQuestions = Object.values(answers).map(answer => {
    const question = allQuestions.find(q => q.id === answer.question_id)
    
    if (!question) {
      throw new Error(`Question with id ${answer.question_id} not found`)
    }
    
    const baseAnswer = {
      question_group: question.group,
      question_id: answer.question_id,
    }

    switch (answer.answer_type) {
      case 'free_answer':
        return {
          ...baseAnswer,
          free_answer: answer.answer_value || '',
        }

      case 'boolean': {
        // Для boolean типа отправляем bool значение первой выбранной опции
        const selectedOption = answer.selected_options?.[0]
        if (selectedOption && question) {
          const option = question.options.find(opt => opt.id === selectedOption)
          const boolTranslation = option?.translations.find(
            t => t.language_id === languageId
          )
          return {
            ...baseAnswer,
            boolean_answer: boolTranslation?.bool || false,
          }
        }
        return {
          ...baseAnswer,
          boolean_answer: false,
        }
      }

      case 'select':
        return {
          ...baseAnswer,
          options: answer.selected_options || [],
        }

      default:
        return baseAnswer
    }
  })

  return {
    project_id: projectId,
    language_id: languageId,
    questions: apiQuestions,
  }
}

export const useSubmitAnswers = () => {
  return useMutation<
    SubmitAnswersResponse,
    Error,
    {
      projectId: number
      languageId: number
      answers: Record<number, QuestionAnswer>
      allQuestions: Question[]
    }
  >({
    mutationFn: async ({ projectId, languageId, answers, allQuestions }) => {
      const requestData = transformAnswersToApiFormat(
        projectId,
        languageId,
        answers,
        allQuestions
      )

      const response = await apiClient.post<SubmitAnswersResponse>(
        '/chat/request/',
        requestData
      )

      return response.data
    },
  })
}
