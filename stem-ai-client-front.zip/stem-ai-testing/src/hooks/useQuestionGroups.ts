import { useQuery } from '@tanstack/react-query'
import apiClient from '../api/axios'
import type { CategoryWithQuestionGroups } from '../api/api.types'

export const useQuestionGroups = (categoryId: number | string) => {
  return useQuery({
    queryKey: ['questionGroups', categoryId],
    queryFn: async (): Promise<CategoryWithQuestionGroups> => {
      const response = await apiClient.get(
        `/projects/${categoryId}/question-groups/`
      )
      return response.data
    },
    enabled: Boolean(categoryId),
    staleTime: 5 * 60 * 1000, // 5 минут
    gcTime: 10 * 60 * 1000, // 10 минут
  })
}
