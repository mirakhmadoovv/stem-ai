import { useQuery } from '@tanstack/react-query'
import { getUserInfo } from '../api/authUser'
import type { UserInfoResponse } from '../types/authTypes'

export const useProfile = () => {
  return useQuery<UserInfoResponse, Error>({
    queryKey: ['profile'],
    queryFn: getUserInfo,
  })
}
