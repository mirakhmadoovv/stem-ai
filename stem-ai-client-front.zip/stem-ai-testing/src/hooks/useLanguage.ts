import { useQuery } from '@tanstack/react-query'
import { getLanguages } from '../api/language'
import type { LanguagesResponse, LanguageType } from '../types/authTypes'
import { getStoredUserInfo, setStoredUserInfo } from '../api/axios'

export const useLanguages = () => {
  return useQuery<LanguagesResponse, Error>({
    queryKey: ['languages'],
    queryFn: getLanguages,
  })
}

export const useChangeLanguage = () => {
  const changeLanguage = (language: LanguageType) => {
    const userInfo = getStoredUserInfo()
    if (userInfo) {
      userInfo.language = language
      setStoredUserInfo(userInfo)
    }
  }

  return { changeLanguage }
}
