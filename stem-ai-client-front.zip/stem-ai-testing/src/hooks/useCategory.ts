import { useQuery, type UseQueryOptions } from '@tanstack/react-query'
import type { ApiResponse, CategoryType } from '../api/api.types'
import { getCategories, getCategoryById } from '../api/category'

export const useCategories = (
  params: string,
  options?: UseQueryOptions<ApiResponse<CategoryType>, Error>
) => {
  return useQuery<ApiResponse<CategoryType>, Error>({
    queryKey: ['categories', params],
    queryFn: () => getCategories(params),
    staleTime: 1000 * 60 * 10,
    ...options,
  })
}

export const useCategoryById = (id: number) => {
  return useQuery<CategoryType, Error>({
    queryKey: ['category', id],
    queryFn: () => getCategoryById(id),
  })
}
