import { useQuery } from '@tanstack/react-query'
import apiClient from '../api/axios'
import type { QuestionGroupWithQuestions } from '../api/api.types'

export const useQuestions = (questionGroupId: number | string) => {
  return useQuery({
    queryKey: ['questions', questionGroupId],
    queryFn: async (): Promise<QuestionGroupWithQuestions> => {
      const response = await apiClient.get(
        `/question-group/${questionGroupId}/`
      )
      return response.data
    },
    enabled: Boolean(questionGroupId),
    staleTime: 5 * 60 * 1000, // 5 минут
    gcTime: 10 * 60 * 1000, // 10 минут
  })
}
