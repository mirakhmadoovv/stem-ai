// Типы для запросов и ответов аутентификации

import type { ApiResponse } from "../api/api.types";

// Запрос на вход
export interface LoginPayload {
  username: string;
  password: string;
}

// Ответ на вход
export interface LoginResponse {
  refresh: string;
  access: string;
}

// Ошибка входа
export interface LoginErrorResponse {
  detail: string;
}

// Запрос на регистрацию
export interface RegisterPayload {
  username: string;
  email: string;
  password: string;
  language: number;
}

// Ответ на регистрацию
export interface RegisterResponse {
  id: number;
  username: string;
  first_name: string;
  last_name: string;
  phone: string;
  role: string;
  language: {
    id: number;
    code: string;
    name: string;
  };
  email_verified: boolean;
  email: string;
  is_active_user: boolean;
  total_tokens: number;
}

// Ошибки регистрации
export interface RegisterErrorResponse {
  username?: string[];
  email?: string[];
  password?: string[];
}

// Запрос на обновление токена
export interface RefreshTokenPayload {
  refresh: string;
}

// Ответ на обновление токена
export interface RefreshTokenResponse {
  access: string;
}

// Ответ с информацией о пользователе
export interface UserInfoResponse {
  id: number;
  username: string;
  first_name: string;
  last_name: string;
  phone: string;
  role: string;
  language: {
    id: number;
    code: string;
    name: string;
  };
  email_verified: boolean;
  email: string;
  is_active_user: boolean;
  total_tokens: number;
}

// Ответ с языками
// export interface LanguagesResponse {
//   data: {
//     id: number;
//     code: string;
//     name: string;
//   }[];
//   pagination: {
//     total: number;
//     per_page: number;
//     current_page: number;
//     last_page: number;
//     next_page_url: string | null;
//     prev_page_url: string | null;
//   };
// }
export interface LanguageType {
  id: number;
  code: string;
  name: string;
}
export type LanguagesResponse = ApiResponse<LanguageType>
