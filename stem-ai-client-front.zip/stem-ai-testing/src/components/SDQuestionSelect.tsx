import React, { useEffect, useRef, useState } from "react";

type Option = {
  label: string;
  value: string;
};

type SDQuestionSelectorProps = {
  id: string;
  question: string;
  type: "radio" | "checkbox" | "select";
  options: Option[];
  value?: string | string[];
  onChange: (value: string | string[]) => void;
};

export const SDQuestionSelector: React.FC<SDQuestionSelectorProps> = ({
  id,
  question,
  type,
  options,
  value,
  onChange,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleCheckboxChange = (checkedValue: string) => {
    const current = Array.isArray(value) ? value : [];
    const newValue = current.includes(checkedValue)
      ? current.filter((v) => v !== checkedValue)
      : [...current, checkedValue];
    onChange(newValue);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleOption = (optValue: string) => {
    const currentValue = Array.isArray(value) ? value : [];
    const newValue = currentValue.includes(optValue)
      ? currentValue.filter((v) => v !== optValue)
      : [...currentValue, optValue];
    onChange(newValue);
  };

  return (
    <div>
      <p className="font-semibold mb-2">{question}</p>

      {/* RADIO */}
      {type === "radio" &&
        options.map((opt) => (
          <label key={opt.value} className="mb-2 d-flex flex-col">
            <input
              type="radio"
              name={id}
              value={opt.value}
              checked={value === opt.value}
              onChange={() => onChange(opt.value)}
              className="sd-question-select"
            />
            <span className="sd-question-answer">{opt.label}</span>
          </label>
        ))}

      {/* CHECKBOX */}
      {type === "checkbox" &&
        options.map((opt) => (
          <label key={opt.value} className="mb-2 d-flex flex-col">
            <input
              type="checkbox"
              value={opt.value}
              checked={Array.isArray(value) && value.includes(opt.value)}
              onChange={() => handleCheckboxChange(opt.value)}
              className="sd-question-select"
            />
            <span className="sd-question-answer">{opt.label}</span>
          </label>
        ))}

      {/* SELECT (multiselect) */}
      {type === "select" && (
        <div className="relative" ref={containerRef}>
          <div
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="border p-2 rounded cursor-pointer min-h-[40px] d-flex flex-wrap gap-2"
          >
            {(!value || (Array.isArray(value) && value.length === 0)) && (
              <span className="text-gray-400 cursor-pointer">Выберите...</span>
            )}
            {Array.isArray(value) &&
              (value || []).map((val) => {
                const label =
                  options.find((o) => o.value === val)?.label || val;
                return (
                  <span
                    key={val}
                    className="sd-question-multiselect rounded-pill px-3 py-2 me-2"
                  >
                    <span className="me-2">{label}</span>
                    <button
                      type="button"
                      className="btn-close btn-close-black btn-sm ms-auto"
                      aria-label="Remove"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleOption(val);
                      }}
                    />
                  </span>
                );
              })}
          </div>

          {dropdownOpen && (
            <div className="absolute z-10 mt-1 w-full bg-white border rounded shadow max-h-60 overflow-y-auto cursor-pointer">
              {options.map((opt) => (
                <div
                  key={opt.value}
                  onClick={() => toggleOption(opt.value)}
                  className={`px-3 py-2 cursor-pointer hover:bg-gray-100 ${
                    Array.isArray(value) && value.includes(opt.value)
                      ? "bg-gray-100 font-semibold"
                      : ""
                  }`}
                >
                  {opt.label}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
