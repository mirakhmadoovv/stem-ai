import React from "react";

interface Category {
  title: string;
  sub: string;
}

interface SDCategoryProps {
  categories: Category[];
  onCategoryClick: (category: Category) => void;
}

const SDCategoryCard: React.FC<SDCategoryProps> = ({
  categories,
  onCategoryClick,
}) => {
  return (
    <div className="row">
      {categories.map((cat, index) => (
        <div
          key={index}
          className="col-sm-6 col-md-4 col-lg-3 mb-4"
          onClick={() => onCategoryClick(cat)}
          style={{ cursor: "pointer" }}
        >
          <div className="card h-100 shadow-sm">
            <div className="card-body d-flex flex-column align-items-start gap-3">
              <div className="fs-3">
                <img src="/icons/item.svg" alt="" />
              </div>
              <div>
                <h5 className="sd-card-title mb-1">{cat.title}</h5>
                <p className="card-text text-muted mb-0">{cat.sub}</p>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SDCategoryCard;
