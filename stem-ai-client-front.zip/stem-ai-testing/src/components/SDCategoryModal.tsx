import React from "react";
import SDSubCategoryCard from "./SDSubCategoryCard";
import { useNavigate } from "react-router";

interface Category {
  title: string;
  sub: string;
  icon?: string;
}

interface SDCategoryModalProps {
  show: boolean;
  categoryList: Category[];
  onClose: () => void;
  onCategoryClick: (category: Category) => void;
}

const SDCategoryModal: React.FC<SDCategoryModalProps> = ({
  show,
  categoryList,
  onClose,
  onCategoryClick,
}) => {
  const navigate = useNavigate();
  if (!show) return null;

  const handleCategoryClick = (category: Category) => {
    if (onCategoryClick) {
      onCategoryClick(category);
    }
    navigate(`/category/${encodeURIComponent(category.title)}`);
  };

  return (
    <div className="sd-modal-overlay">
      <div className="sd-modal-content">
        {/* Header */}
        <div className="sd-modal-header">
          <h2 className="sd-modal-text">Выбор категории</h2>
          <button className="sd-modal-close" onClick={onClose}>
            ×
          </button>
        </div>

        {/* Grid */}
        <SDSubCategoryCard
          categories={categoryList}
          onCategoryClick={handleCategoryClick}
        />
      </div>
    </div>
  );
};

export default SDCategoryModal;
