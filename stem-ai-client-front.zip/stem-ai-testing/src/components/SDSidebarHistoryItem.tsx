import { useState } from "react";
import { Dropdown } from "react-bootstrap";
import { BsThreeDotsVertical } from "react-icons/bs";
import { FaTrashAlt } from "react-icons/fa";

const SidebarHistoryItem = ({
  text,
  onClick,
}: {
  text: string;
  onClick: () => void;
}) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="position-relative d-flex justify-content-between align-items-center px-2 py-1"
      style={{ maxWidth: "200px", cursor: "pointer" }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <span className="sd-sidebar-text text-truncate" onClick={onClick}>
        {text}
      </span>

      {isHovered && (
        <Dropdown align="end">
          <Dropdown.Toggle
            as="button"
            className="btn btn-link btn-sm p-0 border-0"
            style={{ boxShadow: "none" }}
          >
            <BsThreeDotsVertical />
          </Dropdown.Toggle>

          <Dropdown.Menu>
            <Dropdown.Item className="text-danger d-flex align-items-center">
              <FaTrashAlt className="me-2" />
              Удалить
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      )}
    </div>
  );
};
export default SidebarHistoryItem;
