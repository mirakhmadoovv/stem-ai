import React from 'react'
import type { Question, QuestionAnswer } from '../../../api/api.types'
import { getStoredUserInfo } from '../../../api/axios'

interface QuestionRendererProps {
  question: Question
  answer: QuestionAnswer | undefined
  onAnswerChange: (answer: QuestionAnswer) => void
}

const QuestionRenderer: React.FC<QuestionRendererProps> = ({
  question,
  answer,
  onAnswerChange,
}) => {
  const language = getStoredUserInfo()?.language

  // Получаем текст вопроса на текущем языке
  const questionText =
    question.translations.find(t => t.language_code === language?.code)
      ?.value || 'Вопрос без названия'

  // Обработчик для свободного ответа
  const handleFreeAnswerChange = (value: string) => {
    onAnswerChange({
      question_id: question.id,
      answer_type: 'free_answer',
      answer_value: value,
    })
  }

  // Обработчик для булевых и множественных вопросов
  const handleOptionChange = (optionId: number, isChecked: boolean) => {
    const currentSelected = answer?.selected_options || []
    let newSelected: number[]

    if (question.type === 'boolean') {
      // Для булевых вопросов только один выбор
      newSelected = isChecked ? [optionId] : []
    } else {
      // Для select вопросов множественный выбор
      if (isChecked) {
        newSelected = [...currentSelected, optionId]
      } else {
        newSelected = currentSelected.filter(id => id !== optionId)
      }
    }

    onAnswerChange({
      question_id: question.id,
      answer_type: question.type,
      selected_options: newSelected,
    })
  }

  // Стили для контейнера вопроса
  const questionStyle = {
    backgroundColor: '#ffffff',
    border: '1px solid #e0e0e0',
    borderRadius: '12px',
    padding: '24px',
    marginBottom: '20px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  }

  const titleStyle = {
    fontSize: '18px',
    fontWeight: '600',
    color: '#212121',
    marginBottom: '8px',
  }

  const inputStyle = {
    width: '100%',
    padding: '12px',
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    fontSize: '16px',
    resize: 'vertical' as const,
    minHeight: '100px',
  }

  const optionStyle = {
    display: 'flex',
    alignItems: 'center',
    padding: '12px',
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    marginBottom: '8px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  }

  const optionHoverStyle = {
    backgroundColor: '#f7f7f7',
    borderColor: '#667eea',
  }

  return (
    <div style={questionStyle}>
      <h3 style={titleStyle}>{questionText}</h3>

      {question.type === 'free_answer' && (
        <textarea
          style={inputStyle}
          placeholder='Введите ваш ответ...'
          value={answer?.answer_value || ''}
          onChange={e => handleFreeAnswerChange(e.target.value)}
        />
      )}

      {(question.type === 'boolean' || question.type === 'select') && (
        <div>
          {question.options.map(option => {
            const optionText =
              option.translations.find(t => t.language_id === language?.id)
                ?.value || 'Вариант без названия'

            const isSelected =
              answer?.selected_options?.includes(option.id) || false

            return (
              <label
                key={option.id}
                style={{
                  ...optionStyle,
                  ...(isSelected ? optionHoverStyle : {}),
                }}>
                <input
                  type={question.type === 'boolean' ? 'radio' : 'checkbox'}
                  name={`question-${question.id}`}
                  checked={isSelected}
                  onChange={e =>
                    handleOptionChange(option.id, e.target.checked)
                  }
                  style={{ marginRight: '12px' }}
                />
                <span style={{ fontSize: '16px', color: '#212121' }}>
                  {optionText}
                </span>
              </label>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default QuestionRenderer
