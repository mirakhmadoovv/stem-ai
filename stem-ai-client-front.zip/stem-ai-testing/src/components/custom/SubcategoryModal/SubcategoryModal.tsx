import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import type { CategoryType } from '../../../api/api.types'
import { getStoredUserInfo } from '../../../api/axios'
import { modalStyles } from '../../../styles/modal.styles'

interface SubcategoryModalProps {
  show: boolean
  selectedCategory: CategoryType
  subcategories: CategoryType[]
  onClose: () => void
}

const SubcategoryModal: React.FC<SubcategoryModalProps> = ({
  show,
  selectedCategory,
  subcategories,
  onClose,
}) => {
  const navigate = useNavigate()
  const [hoveredCardId, setHoveredCardId] = useState<number | null>(null)
  const [isCloseButtonHovered, setIsCloseButtonHovered] = useState(false)

  const language = getStoredUserInfo()?.language

  // Закрываем модальное окно при клике на overlay
  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  // Обработка выбора подкатегории
  const handleSubcategorySelect = (subcategory: CategoryType) => {
    onClose()
    navigate(`/category/${subcategory.id}`)
  }

  // Не рендерим модальное окно если оно не должно быть показано
  if (!show) return null

  return (
    <div style={modalStyles.overlay} onClick={handleOverlayClick}>
      <div style={modalStyles.content}>
        {/* Заголовок модального окна */}
        <div style={modalStyles.header}>
          <h2 style={modalStyles.title}>
            Подкатегории для "
            {selectedCategory.translations.find(
              t => t.language_code === language?.code
            )?.value || 'Неизвестная категория'}
            "
          </h2>
          <button
            style={{
              ...modalStyles.closeButton,
              ...(isCloseButtonHovered ? modalStyles.closeButtonHover : {}),
            }}
            onClick={onClose}
            onMouseEnter={() => setIsCloseButtonHovered(true)}
            onMouseLeave={() => setIsCloseButtonHovered(false)}>
            ×
          </button>
        </div>

        {/* Сетка подкатегорий */}
        {subcategories.length > 0 ? (
          <div style={modalStyles.subcategoriesGrid}>
            {subcategories.map(subcategory => (
              <div
                key={subcategory.id}
                style={{
                  ...modalStyles.subcategoryCard,
                  ...(hoveredCardId === subcategory.id
                    ? modalStyles.subcategoryCardHover
                    : {}),
                }}
                onClick={() => handleSubcategorySelect(subcategory)}
                onMouseEnter={() => setHoveredCardId(subcategory.id)}
                onMouseLeave={() => setHoveredCardId(null)}>
                <img
                  src={subcategory.image || '/icons/item.svg'}
                  alt=''
                  style={modalStyles.subcategoryImage}
                />
                <h5 style={modalStyles.subcategoryTitle}>
                  {subcategory.translations.find(
                    t => t.language_code === language?.code
                  )?.value || 'Без названия'}
                </h5>
              </div>
            ))}
          </div>
        ) : (
          <div
            style={{
              textAlign: 'center',
              padding: '40px 0',
              color: '#838997',
            }}>
            Подкатегории не найдены
          </div>
        )}
      </div>
    </div>
  )
}

export default SubcategoryModal
