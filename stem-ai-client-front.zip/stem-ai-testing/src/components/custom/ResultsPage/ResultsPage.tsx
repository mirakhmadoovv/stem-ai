import React, { useState } from 'react'
import apiClient from '../../../api/axios'
import { resultsPageStyles } from '../../../styles/resultsPage.styles'
import MarkdownRenderer from '../MarkdownRenderer'

interface ResultsPageProps {
  result: string
  messageId: number
  chatTitle: string
  onBackToHome: () => void
  totalSteps?: number
}

const ResultsPage: React.FC<ResultsPageProps> = ({
  result,
  messageId,
  chatTitle,
  onBackToHome,
  totalSteps = 5,
}) => {
  const [isDownloading, setIsDownloading] = useState(false)

  const handleDownloadPdf = async () => {
    setIsDownloading(true)
    try {
      const response = await apiClient.get(
        `/chat/message/${messageId}/to_pdf`,
        {
          responseType: 'blob',
        }
      )

      const blob = new Blob([response.data], { type: 'application/pdf' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${chatTitle}.pdf`
      link.target = '_blank'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error downloading PDF:', error)
    } finally {
      setIsDownloading(false)
    }
  }

  // Форматируем текущую дату как в дизайне
  const formatDate = () => {
    const now = new Date()
    const day = now.getDate().toString().padStart(2, '0')
    const month = (now.getMonth() + 1).toString().padStart(2, '0')
    const year = now.getFullYear()
    const hours = now.getHours().toString().padStart(2, '0')
    const minutes = now.getMinutes().toString().padStart(2, '0')
    return `${day}.${month}.${year} ${hours}:${minutes}`
  }

  return (
    <div style={resultsPageStyles.container}>
      <div style={resultsPageStyles.mainFrame}>
        <div style={resultsPageStyles.contentFrame}>
          {/* Заголовок */}
          <div style={resultsPageStyles.headerFrame}>
            <h2 style={resultsPageStyles.stepTitle}>{totalSteps} шаг</h2>
            <h1 style={resultsPageStyles.mainTitle}>{chatTitle}</h1>
          </div>

          {/* Основной контент */}
          <div style={resultsPageStyles.resultFrame}>
            {/* Основной текст результата с markdown форматированием */}
            <MarkdownRenderer 
              content={result} 
              style={resultsPageStyles.resultText}
            />

            {/* Дата создания */}
            <div style={resultsPageStyles.dateText}>{formatDate()}</div>
          </div>

          {/* Кнопка скачивания */}
          <button
            style={{
              ...resultsPageStyles.downloadButton,
              opacity: isDownloading ? 0.7 : 1,
            }}
            onClick={handleDownloadPdf}
            disabled={isDownloading}>
            {/* Иконка скачивания */}
            <svg
              style={resultsPageStyles.iconStyle}
              viewBox='0 0 20 20'
              fill='currentColor'>
              <path d='M13.75 7.5h-1.25v-5a0.625 0.625 0 0 0 -1.25 0v5h-1.25a0.624 0.624 0 0 0 -0.443 1.067l2.5 2.5a0.623 0.623 0 0 0 0.886 0l2.5 -2.5a0.624 0.624 0 0 0 -0.443 -1.067zm-11.25 5.625v1.25a3.124 3.124 0 0 0 3.125 3.125h8.75a3.124 3.124 0 0 0 3.125 -3.125v-1.25a0.625 0.625 0 1 0 -1.25 0v1.25a1.875 1.875 0 0 1 -1.875 1.875h-8.75a1.875 1.875 0 0 1 -1.875 -1.875v-1.25a0.625 0.625 0 1 0 -1.25 0z' />
            </svg>

            <span style={resultsPageStyles.buttonText}>
              {isDownloading ? 'Скачивание...' : 'Скачать'}
            </span>

            {/* Стрелка */}
            <svg
              style={resultsPageStyles.iconStyle}
              viewBox='0 0 20 20'
              fill='currentColor'>
              <path
                d='M7.5 15l5-5-5-5'
                stroke='currentColor'
                strokeWidth='1.5'
                strokeLinecap='round'
                strokeLinejoin='round'
                fill='none'
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}

export default ResultsPage
