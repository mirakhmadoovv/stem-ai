import React, { useState, useEffect, useRef } from 'react'
import { CheckOutlined } from '@ant-design/icons'
import { stepperStyles } from '../../../styles/stepper.styles'
import { FaChevronDown, FaChevronUp } from 'react-icons/fa6'
import SDButton from '../../SDButton'

export interface StepData {
  id: number
  title: string
  description: string
  isCompleted: boolean
  isActive: boolean
}

interface StepperProps {
  steps: StepData[]
  onStepClick?: (stepIndex: number) => void
  onDownload?: () => void
  isDownloading?: boolean
}

const Stepper: React.FC<StepperProps> = ({
  steps,
  onStepClick,
  onDownload,
  isDownloading = false,
}) => {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  // Определяем стиль иконки для шага
  const getStepIconStyle = (step: StepData) => {
    if (step.isCompleted) {
      return stepperStyles.stepIconCompleted
    } else if (step.isActive) {
      return stepperStyles.stepIconActive
    } else {
      return stepperStyles.stepIconDefault
    }
  }

  // Определяем содержимое иконки
  const getStepIconContent = (step: StepData, index: number) => {
    if (step.isCompleted) {
      return <CheckOutlined style={{ fontSize: '12px' }} />
    } else {
      return <span style={stepperStyles.stepNumber}>{index + 1}</span>
    }
  }

  // Проверяем, является ли шаг финальным и активным
  const isFinalActiveStep = (step: StepData, index: number) => {
    return step.isActive && index === steps.length - 1
  }

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div style={stepperStyles.container} ref={dropdownRef}>
      {steps.map((step, index) => (
        <React.Fragment key={step.id}>
          {/* Шаг */}
          <div
            style={{
              ...stepperStyles.step,
              ...(step.isActive ? stepperStyles.stepActive : {}),
              cursor: onStepClick ? 'pointer' : 'default',
            }}
            onClick={() => onStepClick?.(index)}>
            {/* Иконка шага */}
            <div style={getStepIconStyle(step)}>
              {getStepIconContent(step, index)}
            </div>

            {/* Контент шага */}
            <div
              style={{
                ...stepperStyles.stepContent,
                ...(step.isActive ? stepperStyles.stepContentActive : {}),
              }}>
              {/* Основная информация о шаге */}
              <div style={stepperStyles.stepContent}>
                <h3 style={stepperStyles.stepTitle}>{step.title}</h3>
                <p style={stepperStyles.stepDescription}>{step.description}</p>
              </div>

              {/* Кнопка скачивания для финального активного шага */}
              {/* {isFinalActiveStep(step, index) && onDownload && (
                <button
                  style={{
                    ...stepperStyles.downloadButton,
                    opacity: isDownloading ? 0.7 : 1,
                  }}
                  onClick={e => {
                    e.stopPropagation()
                    onDownload()
                  }}
                  disabled={isDownloading}>
                  <svg
                    style={stepperStyles.downloadIcon}
                    viewBox='0 0 20 20'
                    fill='currentColor'>
                    <path d='M10 3a1 1 0 0 1 1 1v9.586l2.293-2.293a1 1 0 0 1 1.414 1.414l-4 4a1 1 0 0 1-1.414 0l-4-4a1 1 0 1 1 1.414-1.414L9 13.586V4a1 1 0 0 1 1-1zM3 16a1 1 0 0 1 1-1h12a1 1 0 1 1 0 2H4a1 1 0 0 1-1-1z' />
                  </svg>

                  <span style={stepperStyles.downloadButtonText}>
                    {isDownloading ? 'Скачивание...' : 'Скачать'}
                  </span>

                  <svg
                    style={stepperStyles.downloadIcon}
                    viewBox='0 0 20 20'
                    fill='currentColor'>
                    <path
                      d='M7.5 15l5-5-5-5'
                      stroke='currentColor'
                      strokeWidth='1.5'
                      strokeLinecap='round'
                      strokeLinejoin='round'
                      fill='none'
                    />
                  </svg>
                </button>
              )} */}
              {isFinalActiveStep(step, index) && onDownload && (
                <div
                  className='sd-doc-footer'
                  onClick={e => e.stopPropagation()} // предотвратить клик по step'у
                >
                  <div
                    style={{ position: 'relative', display: 'inline-block' }}>
                    <SDButton
                      label='Скачать'
                      onClick={() => setIsOpen(!isOpen)}
                      variant='secondary'
                      size='md'
                      iconLeft={
                        <img src='../icons/sharp-download.png' alt='download' />
                      }
                      iconRight={isOpen ? <FaChevronUp /> : <FaChevronDown />}
                      disabled={isDownloading}
                    />

                    {isOpen && (
                      <div className='sd-btn-opendrower'>
                        <SDButton
                          label={isDownloading ? 'Скачивание...' : 'PDF'}
                          variant='primary'
                          size='md'
                          onClick={() => {
                            onDownload()
                            setIsOpen(false)
                          }}
                          iconLeft={
                            <img src='../icons/pdf-solid.png' alt='PDF' />
                          }
                          style={{ marginBottom: '12px' }}
                          iconRight={
                            <img
                              src='../icons/gray-download.png'
                              alt='download'
                              style={{ width: '18px', height: '18px' }}
                            />
                          }
                          disabled={isDownloading}
                        />

                        {/* <SDButton
                          label={'DOC'}
                          variant='primary'
                          size='md'
                          onClick={() => handleDownload('doc')}
                          iconLeft={
                            <img
                              src='../../icons/microsoft-word.png'
                              alt='DOC'
                            />
                          }
                          iconRight={
                            <img
                              src='../../icons/gray-download.png'
                              alt='download'
                              style={{ width: '18px', height: '18px' }}
                            />
                          }
                        /> */}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Коннектор (не показываем после последнего шага) */}
          {index < steps.length - 1 && (
            <div
              style={{
                ...stepperStyles.connector,
                ...(steps[index + 1].isCompleted || steps[index + 1].isActive
                  ? {}
                  : stepperStyles.connectorInactive),
              }}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  )
}

export default Stepper
