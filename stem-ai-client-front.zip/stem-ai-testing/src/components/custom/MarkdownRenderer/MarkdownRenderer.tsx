import React from 'react'
import ReactMarkdown from 'react-markdown'
import type { CSSProperties } from 'react'
import type { Components } from 'react-markdown'

interface MarkdownRendererProps {
  content: string
  style?: CSSProperties
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({
  content,
  style,
}) => {
  // Стили для markdown элементов
  const markdownStyles = {
    // Основной контейнер
    container: {
      fontFamily: 'var(--font-roboto)',
      fontSize: '16px',
      lineHeight: '1.4',
      color: '#020207',
      ...style,
    } as CSSProperties,

    // Стили для заголовков
    h1: {
      fontFamily: 'var(--font-roboto)',
      fontWeight: '400',
      fontSize: '28px',
      lineHeight: '1.3',
      color: '#020207',
      marginTop: '24px',
      marginBottom: '16px',
    } as CSSProperties,

    h2: {
      fontFamily: 'var(--font-roboto)',
      fontWeight: '400',
      fontSize: '24px',
      lineHeight: '1.3',
      color: '#020207',
      marginTop: '20px',
      marginBottom: '12px',
    } as CSSProperties,

    h3: {
      fontFamily: 'var(--font-roboto)',
      fontWeight: '400',
      fontSize: '20px',
      lineHeight: '1.3',
      color: '#020207',
      marginTop: '16px',
      marginBottom: '8px',
    } as CSSProperties,

    // Стили для параграфов
    p: {
      marginBottom: '16px',
      lineHeight: '1.4',
    } as CSSProperties,

    // Стили для списков
    ul: {
      marginBottom: '16px',
      paddingLeft: '24px',
    } as CSSProperties,

    ol: {
      marginBottom: '16px',
      paddingLeft: '24px',
    } as CSSProperties,

    li: {
      marginBottom: '8px',
      lineHeight: '1.4',
    } as CSSProperties,

    // Стили для выделенного текста
    strong: {
      fontWeight: '600',
      color: '#020207',
    } as CSSProperties,

    em: {
      fontStyle: 'italic',
    } as CSSProperties,

    // Стили для кода
    code: {
      backgroundColor: '#f5f5f5',
      padding: '2px 6px',
      borderRadius: '4px',
      fontFamily: 'var(--font-roboto)',
      fontSize: '14px',
    } as CSSProperties,

    pre: {
      backgroundColor: '#f5f5f5',
      padding: '12px',
      borderRadius: '8px',
      overflow: 'auto',
      marginBottom: '16px',
    } as CSSProperties,

    // Стили для блокцитат
    blockquote: {
      borderLeft: '4px solid #4A83FF',
      paddingLeft: '16px',
      marginLeft: '0',
      marginBottom: '16px',
      fontStyle: 'italic',
      color: '#666',
    } as CSSProperties,
  }

  // Компоненты для кастомного рендеринга
  const components: Components = {
    h1: ({ children, ...props }) => (
      <h1 style={markdownStyles.h1} {...props}>
        {children}
      </h1>
    ),
    h2: ({ children, ...props }) => (
      <h2 style={markdownStyles.h2} {...props}>
        {children}
      </h2>
    ),
    h3: ({ children, ...props }) => (
      <h3 style={markdownStyles.h3} {...props}>
        {children}
      </h3>
    ),
    p: ({ children, ...props }) => (
      <p style={markdownStyles.p} {...props}>
        {children}
      </p>
    ),
    ul: ({ children, ...props }) => (
      <ul style={markdownStyles.ul} {...props}>
        {children}
      </ul>
    ),
    ol: ({ children, ...props }) => (
      <ol style={markdownStyles.ol} {...props}>
        {children}
      </ol>
    ),
    li: ({ children, ...props }) => (
      <li style={markdownStyles.li} {...props}>
        {children}
      </li>
    ),
    strong: ({ children, ...props }) => (
      <strong style={markdownStyles.strong} {...props}>
        {children}
      </strong>
    ),
    em: ({ children, ...props }) => (
      <em style={markdownStyles.em} {...props}>
        {children}
      </em>
    ),
    code: ({ children, ...props }) => (
      <code style={markdownStyles.code} {...props}>
        {children}
      </code>
    ),
    pre: ({ children, ...props }) => (
      <pre style={markdownStyles.pre} {...props}>
        {children}
      </pre>
    ),
    blockquote: ({ children, ...props }) => (
      <blockquote style={markdownStyles.blockquote} {...props}>
        {children}
      </blockquote>
    ),
  }

  return (
    <div style={markdownStyles.container}>
      <ReactMarkdown components={components}>{content}</ReactMarkdown>
    </div>
  )
}

export default MarkdownRenderer
