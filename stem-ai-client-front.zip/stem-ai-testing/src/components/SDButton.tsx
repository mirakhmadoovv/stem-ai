import React from 'react'
import clsx from 'clsx'

type SDButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'success'
  state?: 'default' | 'hover' | 'disabled'
  size?: 'sm' | 'md' | 'lg'
  label: string
  iconLeft?: React.ReactNode
  iconRight?: React.ReactNode
}

const SDButton: React.FC<SDButtonProps> = ({
  variant = 'primary',
  state = 'default',
  size = 'md',
  label,
  iconLeft,
  iconRight,
  className,
  ...rest
}) => {
  const sizeClass = {
    sm: 'btn-sm',
    md: 'btn-md',
    lg: 'btn-lg',
  }[size]

  const variantClass = {
    primary: 'btn sd-btn-blue',
    secondary: 'btn sd-btn-darkblue',
    success: 'btn sd-btn-green',
  }[variant]

  const disabledClass = state === 'disabled' ? 'disabled' : ''
  const buttonClass = clsx(
    'btn d-inline-flex align-items-center gap-2',
    variantClass,
    sizeClass,
    disabledClass,
    className
  )

  return (
    <button
      className={buttonClass}
      disabled={state === 'disabled' || rest.disabled}
      {...rest}>
      <span className='d-flex align-items-center justify-content-center w-100'>
        {iconLeft && <span className='me-2 btn-text'>{iconLeft}</span>}
        <span>{label}</span>
        {iconRight && <span className='ms-2 mt-1 btn-text'>{iconRight}</span>}
      </span>
    </button>
  )
}

export default SDButton
