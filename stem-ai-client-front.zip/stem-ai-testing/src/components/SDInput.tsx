import React from "react";
import clsx from "clsx";

export type SDInputProps = React.InputHTMLAttributes<HTMLInputElement> & {
  name: string;
  label?: string;
  error?: string;
  className?: string;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
};

const SDInput: React.FC<SDInputProps> = ({
  name,
  label,
  error,
  className = "",
  iconLeft,
  iconRight,
  ...rest
}) => {
  const hasError = !!error;

  return (
    <div className="flex flex-col gap-1">
      {label && (
        <label htmlFor={name} className="text-sm font-medium">
          {label}
        </label>
      )}
      <div className="relative">
        {iconLeft && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            {iconLeft}
          </span>
        )}
        <input
          id={name}
          name={name}
          type="text"
          {...rest}
          className={clsx(
            "w-full rounded-md border outline-none transition pl-10 pr-10 py-2",
            rest.disabled && "bg-gray-100 text-gray-400 cursor-not-allowed",
            hasError ? "border-red-500" : "border-[#85819E]",
            !rest.disabled && !hasError && "focus:border-[#25CF9F]",
            className
          )}
        />
        {iconRight && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
            {iconRight}
          </span>
        )}
      </div>
      {hasError && <div className="sd-input-error">{error}</div>}
    </div>
  );
};

export default SDInput;
