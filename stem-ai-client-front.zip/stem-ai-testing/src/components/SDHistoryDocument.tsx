import React, { useEffect, useRef, useState } from 'react'
import SDButton from './SDButton'
import { FaChevronDown, FaChevronUp } from 'react-icons/fa6'
import apiClient from '../api/axios'
import type { HistoryType } from '../api/api.types'
import MarkdownRenderer from './custom/MarkdownRenderer'

type SDHistoryDocumentProps = {
  historyDataId: HistoryType
}

const SDHistoryDocument: React.FC<SDHistoryDocumentProps> = ({
  historyDataId,
}) => {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  console.log(historyDataId)

  const formatDate = (dateString: string) => {
    const now = new Date(dateString)
    const day = now.getDate().toString().padStart(2, '0')
    const month = (now.getMonth() + 1).toString().padStart(2, '0')
    const year = now.getFullYear()
    const hours = now.getHours().toString().padStart(2, '0')
    const minutes = now.getMinutes().toString().padStart(2, '0')
    return `${day}.${month}.${year} ${hours}:${minutes}`
  }

  /* const handleDownload = (format: 'pdf' | 'doc') => {
    // В реальном проекте замените ссылки на реальные файлы
    const fileUrl = `/files/sample.${format}`
    const link = document.createElement('a')
    link.href = fileUrl
    link.download = `ТЗ.${format}`
    link.click()
  } */

  const handleDownloadPdf = async () => {
    try {
      const response = await apiClient.get(
        `/chat/message/${historyDataId.messages[0].id}/to_pdf`,
        {
          responseType: 'blob',
        }
      )

      const blob = new Blob([response.data], { type: 'application/pdf' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${historyDataId.title}.pdf`
      link.target = '_blank'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error downloading PDF:', error)
    }
  }

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div className='sd-doc-container'>
      {/* <h6 className='sd-doc-step'></h6> */}
      <h4 className='sd-doc-step'>Техническое задание к проекту</h4>
      {/* <h6 className='sd-doc-step'>{historyDataId.title}</h6> */}
      <p className='sd-doc-title'>{historyDataId.title}</p>

      <MarkdownRenderer
        content={historyDataId.messages[0].response_text}
        style={{ fontSize: '16px', lineHeight: '1.4' }}
      />

      {historyDataId?.messages.map((block, index) => (
        <div key={index}>
          <h2 className='sd-doc-footerdata'>{formatDate(block.created_at)}</h2>
        </div>
      ))}

      <div className='sd-doc-footer' style={{ marginTop: '2rem' }}>
        <div
          ref={dropdownRef}
          style={{ position: 'relative', display: 'inline-block' }}>
          <SDButton
            label='Скачать'
            onClick={() => setIsOpen(!isOpen)}
            variant='secondary'
            size='md'
            iconLeft={<img src='../icons/sharp-download.png' alt='download' />}
            iconRight={isOpen ? <FaChevronUp /> : <FaChevronDown />}
          />

          {isOpen && (
            <div className='sd-btn-opendrower'>
              <SDButton
                label={'PDF'}
                variant='primary'
                size='md'
                onClick={() => {
                  handleDownloadPdf(), console.log('PDF downloaded')
                }}
                iconLeft={<img src='../icons/pdf-solid.png' alt='PDF' />}
                style={{ marginBottom: '12px' }}
                iconRight={
                  <img
                    src='../icons/gray-download.png'
                    alt='download'
                    style={{ width: '18px', height: '18px' }}
                  />
                }
              />

              {/*  <SDButton
                label={'DOC'}
                variant='primary'
                size='md'
                onClick={() => handleDownload('doc')}
                iconLeft={
                  <img src='../../icons/microsoft-word.png' alt='DOC' />
                }
                iconRight={
                  <img
                    src='../../icons/gray-download.png'
                    alt='download'
                    style={{ width: '18px', height: '18px' }}
                  />
                }
              /> */}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default SDHistoryDocument
