import { Steps } from "antd";
import SDButton from "./SDButton";
import type { StepsProps } from "antd";
import React, { useEffect, useRef, useState } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa6";

interface SDStepSidebarProps {
  items: StepsProps["items"];
  className?: string;
  onStepClick: (step: number) => void;
}

const SDStepSidebar: React.FC<SDStepSidebarProps> = ({
  items,
  className = "sd-stepper-sidebar",
  onStepClick,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleDownload = (format: "pdf" | "doc") => {
    const fileUrl = `/files/sample.${format}`;
    const link = document.createElement("a");
    link.href = fileUrl;
    link.download = `ТЗ.${format}`;
    link.click();
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <Steps
      direction="vertical"
      size="small"
      onChange={onStepClick}
      className={className}
      items={items?.map((item, index) => {
        const isLast = index === items.length - 1;

        return {
          ...item,
          description: isLast ? (
            <div
              style={{
                backgroundColor: "#e6f0ff",
                padding: "12px",
                borderRadius: "8px",
                marginTop: "8px",
              }}
            >
              {item.description && (
                <div style={{ marginBottom: "12px" }}>{item.description}</div>
              )}

              {/* dropdown кнопка */}
              <div
                ref={dropdownRef}
                style={{ position: "relative", display: "inline-block" }}
              >
                <SDButton
                  label="Скачать"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsOpen(!isOpen);
                  }}
                  variant="secondary"
                  size="md"
                  iconLeft={
                    <img src="/icons/sharp-download.png" alt="download" />
                  }
                  iconRight={isOpen ? <FaChevronUp /> : <FaChevronDown />}
                />

                {isOpen && (
                  <div
                    className="sd-btn-opendrower"
                    style={{
                      position: "absolute",
                      zIndex: 1000,
                      background: "#fff",
                      padding: "12px",
                      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                      borderRadius: "8px",
                      marginTop: "8px",
                    }}
                  >
                    <SDButton
                      label="PDF"
                      variant="primary"
                      size="md"
                      onClick={() => handleDownload("pdf")}
                      iconLeft={<img src="./icons/pdf-solid.png" alt="PDF" />}
                      style={{ marginBottom: "12px" }}
                      iconRight={
                        <img
                          src="./icons/gray-download.png"
                          alt="download"
                          style={{ width: "18px", height: "18px" }}
                        />
                      }
                    />
                    <SDButton
                      label="DOC"
                      variant="primary"
                      size="md"
                      onClick={() => handleDownload("doc")}
                      iconLeft={
                        <img src="./icons/microsoft-word.png" alt="DOC" />
                      }
                      iconRight={
                        <img
                          src="./icons/gray-download.png"
                          alt="download"
                          style={{ width: "18px", height: "18px" }}
                        />
                      }
                    />
                  </div>
                )}
              </div>
            </div>
          ) : (
            item.description || null
          ), // безопасный fallback
        };
      })}
    />
  );
};

export default SDStepSidebar;

/* import { Steps } from "antd";
import type { StepsProps } from "antd";
import React from "react";

// Тип для пропсов компонента
interface SDStepSidebarProps {
  current: number;
  items: StepsProps["items"];
  className?: string;
  onStepClick: (step: number) => void;
}

const SDStepSidebar: React.FC<SDStepSidebarProps> = ({
  current,
  items,
  className = "sd-stepper-sidebar",
  onStepClick,
}) => {
  return (
    <Steps
      direction="vertical"
      size="small"
      className={className}
      current={current}
      items={items}
      onChange={onStepClick}
    />
  );
};

export default SDStepSidebar; */
