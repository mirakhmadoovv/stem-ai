import React, { useRef, useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { toast } from 'react-toastify'
import { AxiosError } from 'axios'
import SDInput from '../components/SDInput'
import SDButton from '../components/SDButton'
import { registerUser } from '../api/authRegister'
import { IoChevronDown } from 'react-icons/io5'
import { getLanguages } from '../api/language'
import type { RegisterErrorResponse } from '../types/authTypes'

// Интерфейс для языка
interface Language {
  id: number
  code: string
  name: string
}

// Интерфейс для пропсов компонента
interface RegisterPageProps {
  onRegisterSuccess: () => void
}

// Схема валидации для формы регистрации
const registerSchema = z.object({
  username: z.string().min(1, 'Имя пользователя обязательно'),
  email: z.string().email('Некорректный email').min(1, 'Email обязателен'),
  password: z.string().min(8, 'Минимум 8 символов'),
  language: z.number().min(1, 'Выберите язык'),
})

// Тип данных формы на основе схемы
type RegisterFormData = z.infer<typeof registerSchema>

const RegisterPage: React.FC<RegisterPageProps> = ({ onRegisterSuccess }) => {
  // Состояние для выбранного языка и выпадающего списка
  const [selectedLanguage, setSelectedLanguage] = useState<Language | null>(
    null
  )
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [isLoadingLanguages, setIsLoadingLanguages] = useState(false)
  const [availableLanguages, setAvailableLanguages] = useState<Language[]>([])
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Инициализация react-hook-form с zod валидацией
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      email: '',
      password: '',
      language: selectedLanguage?.id || 0,
    },
  })

  // Загрузка списка языков при монтировании компонента
  useEffect(() => {
    const fetchLanguages = async () => {
      setIsLoadingLanguages(true)
      try {
        const response = await getLanguages()
        if (response.data && response.data.length > 0) {
          setAvailableLanguages(response.data)

          // Установка языка по умолчанию из localStorage или первого доступного
          const savedLanguageId = localStorage.getItem('preferredLanguageId')
          if (savedLanguageId) {
            const savedLanguage = response.data.find(
              lang => lang.id === parseInt(savedLanguageId)
            )
            if (savedLanguage) {
              setSelectedLanguage(savedLanguage)
              setValue('language', savedLanguage.id)
            } else {
              setSelectedLanguage(response.data[0])
              setValue('language', response.data[0].id)
            }
          } else {
            setSelectedLanguage(response.data[0])
            setValue('language', response.data[0].id)
          }
        }
      } catch (error) {
        console.error('Ошибка при загрузке языков:', error)
      } finally {
        setIsLoadingLanguages(false)
      }
    }

    fetchLanguages()
  }, [setValue])

  // Обработчик изменения языка
  const handleLanguageChange = (language: Language) => {
    setSelectedLanguage(language)
    setValue('language', language.id)
    localStorage.setItem('preferredLanguageId', language.id.toString())
    setDropdownOpen(false)
  }

  // Обработчик отправки формы
  const onSubmit = async (data: RegisterFormData) => {
    try {
      const result = await registerUser(data)

      // Сохраняем данные пользователя в localStorage
      if (selectedLanguage) {
        localStorage.setItem(
          'preferredLanguageId',
          selectedLanguage.id.toString()
        )
      }

      toast.success('Регистрация успешна! Войдите в систему.')
      reset()
      onRegisterSuccess()
    } catch (error) {
      if (error instanceof AxiosError) {
        const err = error as AxiosError<RegisterErrorResponse>
        if (err.response?.data) {
          const { username, email, password } = err.response.data

          if (username && username.length > 0) {
            toast.error(`Ошибка: ${username[0]}`)
          } else if (email && email.length > 0) {
            toast.error(`Ошибка: ${email[0]}`)
          } else if (password && password.length > 0) {
            toast.error(`Ошибка: ${password[0]}`)
          } else {
            toast.error('Ошибка регистрации')
          }
        } else if (err.request) {
          toast.error('Нет ответа от сервера')
        } else {
          toast.error(`Ошибка: ${err.message}`)
        }
      } else {
        toast.error('Произошла неизвестная ошибка')
      }
    }
  }

  // Закрытие выпадающего списка при клике вне его
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <h1>Создание аккаунта</h1>

        {/* Выпадающий список языков */}
        <div className='position-relative' ref={dropdownRef}>
          <div
            className='d-flex align-items-center justify-content-between gap-2 p-2 rounded'
            style={{
              cursor: 'pointer',
              backgroundColor: '#fefeff',
              border: '1px solid #ccccd1',
            }}
            onClick={() => setDropdownOpen(!dropdownOpen)}>
            <div className='d-flex align-items-center gap-2'>
              <span className=''>
                {selectedLanguage?.name || 'Выберите язык'}
              </span>
            </div>
            <span style={{ fontSize: '1rem' }}>
              <IoChevronDown />
            </span>
          </div>

          {dropdownOpen && (
            <div
              className='position-absolute bg-white shadow rounded mt-2 p-2 w-100'
              style={{ right: 0, zIndex: 1000, fontSize: '1rem' }}>
              {availableLanguages.map(language => (
                <div
                  key={language.id}
                  className='d-flex align-items-center gap-2 p-2 rounded'
                  style={{
                    cursor: 'pointer',
                    fontSize: '1rem',
                  }}
                  onClick={() => handleLanguageChange(language)}
                  onMouseEnter={e =>
                    (e.currentTarget.style.backgroundColor = '#ccccd1')
                  }
                  onMouseLeave={e =>
                    (e.currentTarget.style.backgroundColor = 'transparent')
                  }>
                  <span
                    style={{
                      fontSize: '1rem',
                      color:
                        selectedLanguage?.id === language.id
                          ? '#007bff'
                          : '#000',
                    }}>
                    {language.name}
                  </span>
                </div>
              ))}
            </div>
          )}

          {errors.language && (
            <div className='text-danger small mt-1'>
              {errors.language.message}
            </div>
          )}
        </div>

        {/* Поля формы */}
        <SDInput
          type='text'
          placeholder='Имя пользователя'
          className='form-control'
          {...register('username')}
          error={errors.username?.message}
        />

        <SDInput
          type='email'
          placeholder='Email'
          className='form-control'
          {...register('email')}
          error={errors.email?.message}
        />

        <SDInput
          type='password'
          placeholder='Пароль'
          className='form-control'
          {...register('password')}
          error={errors.password?.message}
        />

        <SDButton
          type='submit'
          label={isSubmitting ? 'Загрузка...' : 'Зарегистрироваться'}
          variant='primary'
          disabled={isSubmitting || isLoadingLanguages}
        />
      </form>
    </>
  )
}

export default RegisterPage
