// PricingTable.tsx
import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import SDButton from '../components/SDButton'

type Plan = {
  title: string
  price: string
  users: string
  storage: string
  support: string
  access: string
}

const plans: Plan[] = [
  {
    title: 'Free',
    price: '$0/mo',
    users: '10 users included',
    storage: '2 GB of storage',
    support: 'Email support',
    access: 'Help center access',
  },
  {
    title: 'Pro',
    price: '$15/mo',
    users: '20 users included',
    storage: '10 GB of storage',
    support: 'Priority email support',
    access: 'Help center access',
  },
  {
    title: 'Enterprise',
    price: '$29/mo',
    users: '30 users included',
    storage: '15 GB of storage',
    support: 'Phone and email support',
    access: 'Help center access',
  },
]

const PricingTable: React.FC = () => {
  return (
    <div className='container'>
      <div className='mb-5 mt-5'>
        <h1 className='text-center'>Pricing</h1>
        <p className='text-center'>
          Quickly build an effective pricing table for your potential customers.
        </p>
      </div>
      <div className='row'>
        {plans.map((plan, idx) => (
          <div className='col-md-4' key={idx}>
            <div className='card mb-4 shadow-sm text-start '>
              <div className='card-header'>
                <h4 className='sd-payment-tarif'>{plan.title}</h4>
              </div>
              <div className='card-body'>
                <h1 className='sd-payment-price'>{plan.price}</h1>
                <ul className='list-unstyled mt-3 mb-4'>
                  <li className='sd-payment-description'>{plan.users}</li>
                  <li className='sd-payment-description'>{plan.storage}</li>
                  <li className='sd-payment-description'>{plan.support}</li>
                  <li className='sd-payment-description'>{plan.access}</li>
                </ul>
                <SDButton variant='secondary' size='sm' label='Get Started' />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default PricingTable
