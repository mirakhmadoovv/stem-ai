import React from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { AxiosError } from 'axios'
import { toast } from 'react-toastify'
import { useNavigate } from 'react-router'
import SDInput from '../components/SDInput'
import { loginUser } from '../api/authLogin'
import SDButton from '../components/SDButton'
import { setStoredTokens, setStoredUserInfo } from '../api/axios'
import type { LoginErrorResponse } from '../types/authTypes'
import { getUserInfo } from '../api/authUser'

// Схема валидации для формы входа
const loginSchema = z.object({
  username: z.string().min(1, 'Имя пользователя обязательно'),
  password: z.string().min(6, 'Минимум 6 символов'),
})

// Тип данных формы на основе схемы
type LoginFormData = z.infer<typeof loginSchema>

const LoginPage: React.FC = () => {
  const navigate = useNavigate()

  // Инициализация react-hook-form с zod валидацией
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: 'admin',
      password: 'admin12345',
    },
  })

  // Обработчик отправки формы
  const onSubmit = async (data: LoginFormData) => {
    try {
      const result = await loginUser(data)

      // Сохраняем токены в localStorage
      setStoredTokens({
        access: result.access,
        refresh: result.refresh,
      })
      const userInfo = await getUserInfo()
      setStoredUserInfo(userInfo)
      console.log(userInfo)

      toast.success('Вы успешно вошли в систему!')
      reset()
      navigate('/')
    } catch (error) {
      if (error instanceof AxiosError) {
        if (error.response) {
          // Типизированная обработка ошибки
          const errorData = error.response.data as LoginErrorResponse
          if (errorData.detail) {
            toast.error(`Ошибка: ${errorData.detail}`)
          } else {
            toast.error('Ошибка авторизации')
          }
        } else if (error.request) {
          toast.error('Нет ответа от сервера')
        } else {
          toast.error(`Ошибка: ${error.message}`)
        }
      } else {
        toast.error('Произошла неизвестная ошибка')
      }
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <h1>Вход в систему</h1>

      <SDInput
        type='text'
        placeholder='Имя пользователя'
        className='form-control'
        {...register('username')}
        error={errors.username?.message}
      />

      <SDInput
        type='password'
        placeholder='Пароль'
        className='form-control'
        {...register('password')}
        error={errors.password?.message}
      />

      <a href='#'>Забыли пароль?</a>

      <SDButton
        type='submit'
        label={isSubmitting ? 'Загрузка...' : 'Войти'}
        variant='primary'
        disabled={isSubmitting}
      />
    </form>
  )
}

export default LoginPage
