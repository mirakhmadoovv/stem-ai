import React, { useState, useMemo } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Spin, Button, message } from 'antd'
import { ArrowLeftOutlined, ArrowRightOutlined } from '@ant-design/icons'
import { useQuestionGroups } from '../hooks/useQuestionGroups'
import { useQuestions } from '../hooks/useQuestions'
import { useSubmitAnswers } from '../hooks/useSubmitAnswers'
import { getStoredUserInfo } from '../api/axios'
import apiClient from '../api/axios'
import { QuestionRenderer } from '../components/custom/QuestionComponents'
import Stepper, { type StepData } from '../components/custom/Stepper'
import { ResultsContent } from '../components/custom/ResultsPage'
import type { QuestionAnswer, Question } from '../api/api.types'
import { toast } from 'react-toastify'
import SDButton from '../components/SDButton'

const Questions: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [currentGroupIndex, setCurrentGroupIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, QuestionAnswer>>({})
  const [showResults, setShowResults] = useState(false)
  const [resultsData, setResultsData] = useState<{
    result: string
    messageId: number
    chatTitle: string
  } | null>(null)
  const [isStepperDownloading, setIsStepperDownloading] = useState(false)

  const language = getStoredUserInfo()?.language
  const submitAnswersMutation = useSubmitAnswers()

  // Получаем группы вопросов для категории
  const {
    data: categoryData,
    isLoading: isLoadingGroups,
    error: groupsError,
  } = useQuestionGroups(id || '')

  // Получаем текущую группу вопросов
  const currentGroup = categoryData?.question_groups?.[currentGroupIndex]

  // Получаем вопросы для текущей группы
  const {
    data: questionsData,
    isLoading: isLoadingQuestions,
    error: questionsError,
  } = useQuestions(currentGroup?.id || '')

  // Собираем все вопросы для передачи в API
  // Нам нужны все вопросы из всех групп, чтобы правильно определить question_group
  const [allQuestions, setAllQuestions] = useState<Question[]>([])

  // Обновляем список всех вопросов при загрузке новой группы
  React.useEffect(() => {
    if (questionsData?.questions) {
      setAllQuestions(prev => {
        // Убираем дубликаты по ID
        const existingIds = new Set(prev.map(q => q.id))
        const newQuestions = questionsData.questions.filter(
          q => !existingIds.has(q.id)
        )
        return [...prev, ...newQuestions]
      })
    }
  }, [questionsData])

  // Подготавливаем данные для степпера
  const stepperData: StepData[] = useMemo(() => {
    if (!categoryData?.question_groups) return []

    return categoryData.question_groups
      .sort((a, b) => a.order - b.order)
      .map((group, index) => {
        const groupName =
          group.translations.find(t => t.language_code === language?.code)
            ?.value || `Группа ${index + 1}`

        return {
          id: group.id,
          title: `${index + 1} шаг`,
          description: groupName,
          // Если показываем результаты, все шаги вопросов завершены
          isCompleted: showResults ? true : index < currentGroupIndex,
          // Если показываем результаты, ни один шаг вопросов не активен
          isActive: showResults ? false : index === currentGroupIndex,
        }
      })
      .concat([
        {
          id: -1,
          title: `${categoryData.question_groups.length + 1} шаг`,
          description: 'Готовое ТЗ',
          isCompleted: showResults,
          isActive: showResults,
        },
      ])
  }, [categoryData, currentGroupIndex, language, showResults])

  // Обработчик изменения ответа
  const handleAnswerChange = (answer: QuestionAnswer) => {
    setAnswers(prev => ({
      ...prev,
      [answer.question_id]: answer,
    }))
  }

  // Переход к следующей группе вопросов
  const handleNextGroup = async () => {
    if (!categoryData?.question_groups || !questionsData) return

    const hasAnsweredAllQuestions = questionsData.questions.every(question => {
      const answer = answers[question.id]
      if (!answer) return false

      if (question.type === 'free_answer') {
        return Boolean(answer.answer_value?.trim())
      } else {
        return Boolean(answer.selected_options?.length)
      }
    })

    if (!hasAnsweredAllQuestions) {
      toast.warning('Пожалуйста, ответьте на все вопросы в этой группе')
      return
    }

    if (currentGroupIndex < categoryData.question_groups.length - 1) {
      setCurrentGroupIndex(prev => prev + 1)
    } else {
      // Последняя группа - отправляем форму
      await handleSubmitAnswers()
    }
  }

  // Переход к предыдущей группе вопросов
  const handlePreviousGroup = () => {
    if (currentGroupIndex > 0) {
      setCurrentGroupIndex(prev => prev - 1)
    }
  }

  // Отправка ответов
  const handleSubmitAnswers = async () => {
    if (!categoryData || !language) return

    try {
      const result = await submitAnswersMutation.mutateAsync({
        projectId: parseInt(id || '0'),
        languageId: language.id,
        answers,
        allQuestions,
      })

      // Сохраняем данные результата
      setResultsData({
        result: result.result,
        messageId: result.chat.message_id,
        chatTitle: result.chat.title,
      })
      setShowResults(true)
      toast.success('Ответы успешно отправлены!')
    } catch (error) {
      console.error('Error submitting answers:', error)
      toast.error('Произошла ошибка при отправке ответов')
    }
  }

  // Возврат на главную страницу
  const handleBackToHome = () => {
    navigate('/')
  }

  // Обработчик скачивания из степпера
  const handleStepperDownload = async () => {
    if (!resultsData) return

    setIsStepperDownloading(true)
    try {
      const response = await apiClient.get(
        `/chat/message/${resultsData.messageId}/to_pdf`,
        {
          responseType: 'blob',
        }
      )

      const blob = new Blob([response.data], { type: 'application/pdf' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${resultsData.chatTitle}.pdf`
      link.target = '_blank'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error downloading from stepper:', error)
    } finally {
      setIsStepperDownloading(false)
    }
  }

  // Обработчик клика по шагу в степпере
  const handleStepClick = (stepIndex: number) => {
    if (stepIndex < stepperData.length - 1 && stepIndex <= currentGroupIndex) {
      setCurrentGroupIndex(stepIndex)
    }
  }

  // Стили
  const containerStyle = {
    display: 'flex',
    minHeight: '100vh',
    backgroundColor: '#f5f5f5',
  }

  const mainContentStyle = {
    flex: 1,
    padding: '24px',
    margin: '0 auto',
  }

  const headerStyle = {
    backgroundColor: '#ffffff',
    padding: '24px',
    borderRadius: '12px',
    marginBottom: '24px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  }

  const navigationStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: '24px',
    padding: '16px 0',
  }

  // Загрузка или ошибка
  if (isLoadingGroups) {
    return (
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
        }}>
        <Spin size='large' />
      </div>
    )
  }

  if (groupsError || !categoryData) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <h2>Ошибка загрузки данных</h2>
        <p>Не удалось загрузить группы вопросов для этой категории</p>
        <Button onClick={handleBackToHome}>Вернуться на главную</Button>
      </div>
    )
  }

  const categoryName =
    categoryData.translations.find(t => t.language_code === language?.code)
      ?.value || 'Категория без названия'

  const currentGroupName =
    currentGroup?.translations.find(t => t.language_code === language?.code)
      ?.value || 'Группа без названия'

  return (
    <div style={containerStyle}>
      <div style={mainContentStyle}>
        {/* Заголовок */}
        <div style={headerStyle}>
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={handleBackToHome}
            style={{ marginBottom: '16px' }}>
            Назад к категориям
          </Button>
          {/* Мобильная шапка с шагом */}
          <div
            className='d-block d-md-none'
            style={{
              backgroundColor: 'var(--color-blue)',
              color: 'white',
              padding: '1rem',
              borderTopLeftRadius: '8px',
              borderTopRightRadius: '8px',
              marginBottom: '12px',
            }}>
            <div style={{ fontSize: '14px' }}>
              Раздел {currentGroupIndex + 1} из{' '}
              {categoryData.question_groups.length + 1}
            </div>
            <div
              style={{ fontSize: '18px', fontWeight: 600, marginTop: '4px' }}>
              {showResults && resultsData
                ? 'Техническое задание к проекту'
                : currentGroupName}
            </div>
          </div>

          <h1
            style={{
              margin: 0,
              color: '#212121',
              fontSize: '24px',
              fontWeight: 'bold',
            }}>
            {categoryName}
          </h1>
          <h3
            style={{
              margin: '8px 0 0 0',
              color: '#838997',
              fontWeight: 'normal',
              fontSize: '12px',
            }}>
            {showResults && resultsData
              ? 'Техническое задание к проекту'
              : `${currentGroupName} (${currentGroupIndex + 1} из ${
                  categoryData.question_groups.length
                })`}
          </h3>
        </div>

        {/* Контент: Вопросы или Результаты */}
        {showResults && resultsData ? (
          /* Показываем результаты */
          <ResultsContent
            result={resultsData.result}
            messageId={resultsData.messageId}
            chatTitle={resultsData.chatTitle}
          />
        ) : isLoadingQuestions ? (
          <div style={{ textAlign: 'center', padding: '50px' }}>
            <Spin size='large' />
          </div>
        ) : questionsError || !questionsData ? (
          <div style={{ textAlign: 'center', padding: '50px' }}>
            <h3>Ошибка загрузки вопросов</h3>
            <p>Не удалось загрузить вопросы для этой группы</p>
          </div>
        ) : (
          <>
            {questionsData.questions.map(question => (
              <QuestionRenderer
                key={question.id}
                question={question}
                answer={answers[question.id]}
                onAnswerChange={handleAnswerChange}
              />
            ))}

            {/* Навигация */}
            <div style={navigationStyle}>
              {/* <Button
                onClick={handlePreviousGroup}
                disabled={currentGroupIndex === 0}
                icon={<ArrowLeftOutlined />}>
                Предыдущая группа
              </Button> */}

              <SDButton
                variant='primary'
                state='default'
                size='md'
                label='Предыдущая группа'
                iconLeft={<ArrowLeftOutlined />}
                onClick={handlePreviousGroup}
                disabled={currentGroupIndex === 0}
              />

              <span className='d-none d-md-block' style={{ color: '#838997' }}>
                Группа {currentGroupIndex + 1} из{' '}
                {categoryData.question_groups.length}
              </span>

              {/* <Button
                type='primary'
                onClick={handleNextGroup}
                loading={submitAnswersMutation.isPending}
                icon={
                  currentGroupIndex ===
                  categoryData.question_groups.length - 1 ? undefined : (
                    <ArrowRightOutlined />
                  )
                }>
                {currentGroupIndex === categoryData.question_groups.length - 1
                  ? 'Завершить'
                  : 'Следующая группа'}
              </Button> */}

              <SDButton
                variant='secondary'
                state='default'
                size='md'
                label={
                  currentGroupIndex === categoryData.question_groups.length - 1
                    ? 'Завершить'
                    : 'Следующая группа'
                }
                iconRight={<ArrowRightOutlined />}
                onClick={handleNextGroup}
                disabled={submitAnswersMutation.isPending}
              />
            </div>
          </>
        )}
      </div>

      {/* Степпер */}
      <div className='sd-stepper-container'>
        <Stepper
          steps={stepperData}
          onStepClick={handleStepClick}
          onDownload={
            showResults && resultsData ? handleStepperDownload : undefined
          }
          isDownloading={isStepperDownloading}
        />
      </div>
    </div>
  )
}

export default Questions
