import React, { useEffect, useMemo, useState } from 'react'
import { useLocation, useParams } from 'react-router-dom'
import { Spin } from 'antd'

import SDHistoryDocument from '../components/SDHistoryDocument'
import Stepper, { type StepData } from '../components/custom/Stepper'
import apiClient, { getStoredUserInfo } from '../api/axios'
import { useHistoryById } from '../hooks/useHistory'

const HistoryPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const location = useLocation()
  const historyId = Number(id)

  const [currentGroupIndex, setCurrentGroupIndex] = useState(0)
  const [showResults, setShowResults] = useState(false)
  const [isStepperDownloading, setIsStepperDownloading] = useState(false)
  const [resultsData, setResultsData] = useState<{
    result: string
    messageId: number
    chatTitle: string
  } | null>(null)

  const { data: historyDataId, isLoading: isLoadingHistory } =
    useHistoryById(historyId)

  const language = getStoredUserInfo()?.language
  const isHistoryPage = location.pathname.startsWith('/history/')

  useEffect(() => {
    if (!resultsData && historyDataId?.messages?.length) {
      const lastMessage = historyDataId.messages.at(-1)
      if (lastMessage) {
        setResultsData({
          messageId: lastMessage.id,
          result: lastMessage.response_text,
          chatTitle: historyDataId.title,
        })
      }
    }
  }, [historyDataId, resultsData])

  const stepperData: StepData[] = useMemo(() => {
    const allGroups =
      historyDataId?.messages?.flatMap(m =>
        m.questions.map(q => q.question_group)
      ) ?? []

    const uniqueGroups = Array.from(
      new Map(allGroups.map(group => [group.id, group])).values()
    )

    const sortedGroups = uniqueGroups.sort((a, b) => a.order - b.order)

    const steps = sortedGroups.map((group, index) => {
      const groupName =
        group.translations.find(t => t.language_code === language?.code)
          ?.value || `Группа ${index + 1}`

      return {
        id: group.id,
        title: `${index + 1} шаг`,
        description: groupName,
        isCompleted: index < currentGroupIndex,
        isActive: index === currentGroupIndex,
      }
    })

    steps.push({
      id: -1,
      title: `${steps.length + 1} шаг`,
      description: 'Готовое ТЗ',
      isCompleted: showResults,
      isActive: showResults,
    })

    return steps
  }, [historyDataId?.messages, currentGroupIndex, language, showResults])

  useEffect(() => {
    if (stepperData.length > 0) {
      setShowResults(true)
      setCurrentGroupIndex(stepperData.length - 1)
    }
  }, [stepperData.length])

  const handleStepClick = (stepIndex: number) => {
    if (stepIndex < stepperData.length - 1 && stepIndex <= currentGroupIndex) {
      setCurrentGroupIndex(stepIndex)
      setShowResults(false)
    }

    if (stepIndex === stepperData.length - 1) {
      setShowResults(true)
      setCurrentGroupIndex(stepIndex)
    }
  }

  const handleStepperDownload = async () => {
    if (!resultsData) return

    setIsStepperDownloading(true)
    try {
      const response = await apiClient.get(
        `/chat/message/${resultsData.messageId}/to_pdf`,
        {
          responseType: 'blob',
        }
      )

      const blob = new Blob([response.data], { type: 'application/pdf' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${resultsData.chatTitle}.pdf`
      link.target = '_blank'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
      setShowResults(true)
    } catch (error) {
      console.error('Error downloading from stepper:', error)
    } finally {
      setIsStepperDownloading(false)
    }
  }

  if (isLoadingHistory) {
    return (
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
        }}>
        <Spin size='large' />
      </div>
    )
  }

  if (!historyDataId) {
    return (
      <div className='sd-history-container'>
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100vh',
          }}>
          <Spin size='large' />
        </div>
      </div>
    )
  }

  return (
    <div className='sd-history-container'>
      <div className='sd-history-content'>
        <SDHistoryDocument historyDataId={historyDataId} />
      </div>
      <div className='sd-stepper-container'>
        <Stepper
          steps={stepperData}
          onStepClick={handleStepClick}
          onDownload={
            isHistoryPage && resultsData ? handleStepperDownload : undefined
          }
          isDownloading={isStepperDownloading}
        />
      </div>
    </div>
  )
}

export default HistoryPage
