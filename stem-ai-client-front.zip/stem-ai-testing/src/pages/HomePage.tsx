import React, { useState, type CSSProperties } from 'react'
import { useNavigate } from 'react-router-dom'
import { Spin } from 'antd'
import 'bootstrap/dist/css/bootstrap.min.css'

import { useCategories } from '../hooks/useCategory'
import { getStoredUserInfo } from '../api/axios'
import type { CategoryType } from '../api/api.types'
import SubcategoryModal from '../components/custom/SubcategoryModal'

const cardStyle = (isSelected: boolean): CSSProperties => ({
  cursor: 'pointer',
  transform: isSelected ? 'translateY(-5px)' : 'none',
  borderWidth: '1px',
  borderStyle: 'solid',
  borderColor: isSelected ? '#667eea' : '#e0e0e0',
  padding: '1rem',
  transition: 'transform 0.2s',
  userSelect: 'none',
})

const HomePage: React.FC = () => {
  const navigate = useNavigate()
  const [showModal, setShowModal] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | null>(
    null
  )

  const { data: categoriesData, isLoading } = useCategories(
    '?page=1&page_size=40'
  )
  const categories = categoriesData?.data || []
  const language = getStoredUserInfo()?.language

  // Получаем только родительские категории (parent_category === null)
  const parentCategories = categories.filter(
    category => category.parent_category === null
  )

  // Получаем подкатегории для выбранной категории
  const subcategories = selectedCategory
    ? categories.filter(
        category => category.parent_category === selectedCategory.id
      )
    : []

  // Обработка клика по категории
  const handleCategoryClick = (category: CategoryType) => {
    // Находим подкатегории для выбранной категории
    const categorySubcategories = categories.filter(
      cat => cat.parent_category === category.id
    )

    if (categorySubcategories.length > 0) {
      // Если есть подкатегории - открываем модальное окно
      setSelectedCategory(category)
      setShowModal(true)
    } else {
      // Если подкатегорий нет - переходим на страницу вопросов
      navigate(`/category/${category.id}`)
    }
  }

  // Закрытие модального окна
  const handleCloseModal = () => {
    setShowModal(false)
    setSelectedCategory(null)
  }

  return (
    <div className='sd-home-container'>
      {/* Заголовок */}
      <div className='text-center mb-4'>
        <h1 className='sd-home-main-text'>Stem AI</h1>
        <p className='sd-home-paragraph'>
          SteamAI — генератор технических заданий нового уровня Просто
          расскажите, что хотите создать — мы превратим вашу идею в
          профессиональное ТЗ для разработчиков, дизайнеров или команды.
        </p>
      </div>

      {/* Сетка категорий */}
      {isLoading ? (
        <div className='text-center'>
          <Spin />
        </div>
      ) : (
        <div className='sd-category-grid'>
          {parentCategories.map(category => (
            <div
              key={category.id}
              onClick={() => handleCategoryClick(category)}
              className='d-flex flex-column align-items-start gap-3 card h-100 shadow-sm'
              style={cardStyle(false)}>
              <div className='fs-3'>
                <img
                  src={category.image || '/icons/item.svg'}
                  alt=''
                  style={{
                    width: '40px',
                    height: '40px',
                    objectFit: 'cover',
                    borderRadius: '50%',
                  }}
                />
              </div>
              <div>
                <h5 className='sd-card-title mb-1'>
                  {category.translations.find(
                    t => t.language_code === language?.code
                  )?.value || 'Без названия'}
                </h5>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Модальное окно для подкатегорий */}
      {selectedCategory && (
        <SubcategoryModal
          show={showModal}
          selectedCategory={selectedCategory}
          subcategories={subcategories}
          onClose={handleCloseModal}
        />
      )}
    </div>
  )
}

export default HomePage
