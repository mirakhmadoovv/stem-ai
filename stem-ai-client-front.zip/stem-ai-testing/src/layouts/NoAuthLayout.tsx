import { Outlet } from "react-router";

function NoAuthLayout() {
  return (
    <main className="w-100">
      <Outlet />
    </main>
  );
}

export default NoAuthLayout;
