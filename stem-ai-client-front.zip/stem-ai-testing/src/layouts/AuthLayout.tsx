import { Navigate, Outlet, useLocation } from 'react-router'
// import { Outlet } from "react-router";
import { useEffect, useState } from 'react'
import Header from './Header'
import Sidebar from './Sidebar'
import { getStoredTokens } from '../api/axios'

function AuthLayout() {
  const [collapsed, setCollapsed] = useState(true)
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768)

  const toggleSidebar = () => setCollapsed(prev => !prev)
  const token = getStoredTokens()
  const location = useLocation()

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768)
      if (window.innerWidth > 768) {
        setCollapsed(false) // по умолчанию открыт
      } else {
        setCollapsed(true) // по умолчанию скрыт
      }
    }

    handleResize() // вызвать один раз при монтировании
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  return (
    <div className='d-flex vh-100 overflow-hidden'>
      <Sidebar
        collapsed={collapsed}
        toggle={() => setCollapsed(!collapsed)}
        isMobile={isMobile}
      />
      <div className='flex-grow-1 d-flex flex-column overflow-hidden'>
        <Header toggleSidebar={toggleSidebar} />
        <div className='flex-grow-1 overflow-auto'>
          <Outlet />
        </div>
      </div>
    </div>
  )
}

export default AuthLayout
