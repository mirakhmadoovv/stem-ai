import SDButton from '../components/SDButton'
import { IoArrowBack, IoChevronDown } from 'react-icons/io5'
import { useState, useEffect, useRef } from 'react'
import { useLocation, useNavigate } from 'react-router'
import type { LanguageType } from '../types/authTypes'
import { useChangeLanguage, useLanguages } from '../hooks/useLanguage'
import { getStoredUserInfo } from '../api/axios'
import { RxHamburgerMenu } from 'react-icons/rx'

interface HeaderProps {
  toggleSidebar: () => void
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageType | null>(
    null
  )
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const navigate = useNavigate()
  const location = useLocation()

  const { data: languages, isLoading } = useLanguages()
  const user = getStoredUserInfo()
  const userLang = user?.language
  const { changeLanguage } = useChangeLanguage()

  const handleLanguageChange = (lang: LanguageType) => {
    setSelectedLanguage(lang)
    changeLanguage(lang)
    setDropdownOpen(false)
    window.location.reload()
  }

  useEffect(() => {
    if (languages?.data && languages.data.length > 0 && !selectedLanguage) {
      setSelectedLanguage(
        languages.data.find(lang => lang.code === userLang?.code) ||
          languages.data[0]
      )
    }
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [languages])

  return (
    <header className='sd-header-container'>
      <div
        className='sd-burger-container'
        onClick={toggleSidebar}
        style={{ cursor: 'pointer' }}>
        <RxHamburgerMenu size={24} />
      </div>

      <div className='d-flex align-items-center gap-4 ms-auto'>
        <div className='sd-header-upgrade'>
          <img
            src='/icons/lightning.svg'
            alt='Coin'
            style={{ width: '20px', height: '20px' }}
          />
          <span className='sd-header-number'>50</span>
        </div>
        <SDButton
          variant='success'
          label='Upgrade'
          onClick={() => navigate('/payment')}>
          Upgrade
        </SDButton>
        <div
          style={{ width: '1px', height: '24px', backgroundColor: '#E0E0E0' }}
        />
        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <div className='position-relative' ref={dropdownRef}>
            <div
              className='d-flex align-items-center gap-2 p-2 rounded'
              style={{ cursor: 'pointer', backgroundColor: '#f7f7fb' }}
              onClick={() => setDropdownOpen(!dropdownOpen)}>
              <span className='sd-header-language--active'>
                {selectedLanguage?.name || 'Loading...'}
              </span>
              <span style={{ fontSize: '1rem' }}>
                <IoChevronDown />
              </span>
            </div>
            {dropdownOpen && (
              <div
                className='position-absolute bg-white shadow rounded mt-2 p-2 w-100'
                style={{ right: 0, zIndex: 1000 }}>
                {languages?.data.map(lang => (
                  <div
                    key={lang.id}
                    className='d-flex align-items-center gap-2 p-2 rounded'
                    style={{ cursor: 'pointer' }}
                    onClick={() => handleLanguageChange(lang)}
                    onMouseEnter={e =>
                      (e.currentTarget.style.backgroundColor = '#f1f4ff')
                    }
                    onMouseLeave={e =>
                      (e.currentTarget.style.backgroundColor = 'transparent')
                    }>
                    <span className='sd-header-language'>{lang.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  )
}

export default Header
