import React, { useState, useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

import '../styles/auth.css'
import RegisterPage from '../pages/RegisterPage'
import LoginPage from '../pages/LoginPage'
import SDButton from '../components/SDButton'

const AuthPanel: React.FC = () => {
  const location = useLocation()
  const navigate = useNavigate()
  const [showModal, setShowModal] = useState(false)
  const [isSignUp, setIsSignUp] = useState(location.pathname === '/register')

  useEffect(() => {
    setIsSignUp(location.pathname === '/register')
  }, [location.pathname])

  const handleModalClose = () => {
    setShowModal(false)
    navigate('/login') // Переход на логин
  }

  return (
    <div className='auth-page position-relative'>
      {showModal && (
        <div
          className='modal show d-block z-index-1000 position-absolute'
          tabIndex={-1}>
          <div className='modal-dialog modal-dialog-centered w-100'>
            <div className='modal-content'>
              <div className='modal-header'>
                <h5 className='modal-title'>Подтверждение</h5>
              </div>
              <div className='modal-body'>
                <p>Вам на электронную почту отправлена ссылка активации.</p>
              </div>
              <div className='modal-footer'>
                {/* <button onClick={handleModalClose} className="btn btn-primary">
                  Ок
                </button> */}
                <SDButton
                  type='button'
                  variant='primary'
                  label='OK'
                  onClick={handleModalClose}
                />
              </div>
            </div>
          </div>
        </div>
      )}
      <div className={`auth-container ${isSignUp ? 'right-panel-active' : ''}`}>
        <div className='form-container sign-up-container'>
          {isSignUp && (
            <RegisterPage
              onRegisterSuccess={() => {
                setShowModal(true)
              }}
            />
          )}
        </div>
        <div className='form-container sign-in-container'>
          {!isSignUp && <LoginPage />}
        </div>

        <div className='overlay-container'>
          <div className='overlay'>
            <div className='overlay-panel overlay-left'>
              {/* <h1>Welcome Back!</h1> */}
              <p>Войдите в систему, указав свои персональные данные.</p>
              <SDButton
                label='Войти'
                variant='secondary'
                className='ghost'
                onClick={() => navigate('/login')}
              />
            </div>
            <div className='overlay-panel overlay-right'>
              {/* <h1>Hello, Friend!</h1> */}
              <p>
                Введите свои персональные данные и начните путешествие с нами
              </p>
              <SDButton
                label='Зарегистрироваться'
                variant='secondary'
                className='ghost'
                onClick={() => navigate('/register')}
              />
            </div>
          </div>
        </div>
      </div>

      <div className='auth-container-mobile'>
        {isSignUp ? (
          <RegisterPage
            onRegisterSuccess={() => {
              setShowModal(true)
            }}
          />
        ) : (
          <LoginPage />
        )}

        <div className='auth-toggle text-center mt-4 d-flex align-items-center justify-content-center'>
          <p>
            {isSignUp ? 'Уже есть аккаунт?' : 'Нет аккаунта?'}{' '}
            <a
              className='text-primary text-decoration-underline'
              onClick={() => navigate(isSignUp ? '/login' : '/register')}>
              {isSignUp ? 'Войти' : 'Зарегистрироваться'}
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}

export default AuthPanel
