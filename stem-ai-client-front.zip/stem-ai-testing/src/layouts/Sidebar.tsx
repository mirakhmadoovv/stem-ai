import { useEffect, useRef, useState, type FC } from 'react'
import SDButton from '../components/SDButton'
import { FiLogOut, FiTrash2, FiUser } from 'react-icons/fi'
import { FaClockRotateLeft } from 'react-icons/fa6'
import { useLocation, useNavigate } from 'react-router'
import { clearAuth } from '../api/axios'
import { useHistory, useDeleteHistoryById } from '../hooks/useHistory'
import { isToday, isYesterday, parseISO } from 'date-fns'
import { HiDotsVertical } from 'react-icons/hi'

interface SidebarProps {
  collapsed: boolean
  toggle: () => void
  isMobile: boolean
}

const Sidebar: FC<SidebarProps> = ({ collapsed, toggle, isMobile }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [hoveredId, setHoveredId] = useState<number | null>(null)
  const [menuOpenId, setMenuOpenId] = useState<number | null>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)

  const { data: historyData } = useHistory()

  const todayItems = historyData?.data.filter(item =>
    isToday(parseISO(item.created_at))
  )

  const yesterdayItems = historyData?.data.filter(item =>
    isYesterday(parseISO(item.created_at))
  )

  const location = useLocation()
  const isHomePage = location.pathname === '/'
  const navigate = useNavigate()

  const handleClick = () => {
    navigate('/history')
  }

  const { mutate: deleteItem } = useDeleteHistoryById()

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div
      className={`sd-sidebar-container ${
        isMobile
          ? collapsed
            ? 'hidden-mobile'
            : 'full-mobile'
          : collapsed
          ? 'collapsed'
          : 'expanded'
      }`}>
      {collapsed ? (
        <div className='d-flex justify-content-between flex-column align-items-center gap-4 h-100'>
          <div className='d-flex flex-column align-items-center gap-4 pt-3 w-100'>
            <div className='d-flex align-items-center gap-2'>
              <a href='/'>
                <img
                  src='/icons/logoS.svg'
                  alt='Logo'
                  style={{ width: '40px', height: '40px' }}
                />
              </a>
              <div style={{ position: 'relative' }}>
                <button
                  onClick={toggle}
                  style={{ position: 'absolute', left: '0px', top: '-8px' }}
                  className='btn p-0 border-0 bg-transparent mb-2'>
                  <img
                    src='/icons/drower.svg'
                    alt='Drower'
                    style={{ width: '20px', height: '20px' }}
                  />
                </button>
              </div>
            </div>
            {!isHomePage && (
              <SDButton
                variant='primary'
                size='lg'
                label='+'
                className='btn-text'
                onClick={() => navigate('/')}
              />
            )}

            <hr className='w-100' />
            <FaClockRotateLeft
              size={18}
              title='Истории'
              style={{ cursor: 'pointer' }}
            />
          </div>

          <div className='mt-auto pt-3 w-100'>
            <hr className='w-100' />
            <div
              className='d-flex align-items-center justify-content-center mt-3'
              style={{ cursor: 'pointer' }}
              onClick={() => setDropdownOpen(!dropdownOpen)}>
              <div
                className='rounded-circle border-0 bg-secondary d-flex align-items-center justify-content-center'
                style={{ width: 32, height: 32 }}>
                <FiUser size={20} className='text-white' />
              </div>
            </div>
          </div>
          {dropdownOpen && (
            <div
              className='position-absolute shadow rounded p-2'
              ref={dropdownRef}
              style={{
                bottom: '10%',
                left: '10px',
                zIndex: 10,
                maxWidth: '140px',
              }}>
              {/* <div
                className='dropdown-item py-1 px-2 text-dark sd-dropdown-item'
                style={{ cursor: 'pointer' }}
                onClick={() => console.log('Профиль')}>
                Профиль
              </div> */}
              <div
                className='dropdown-item py-1 px-2 text-dark sd-dropdown-item'
                style={{ cursor: 'pointer' }}
                onClick={() => {
                  clearAuth()
                  navigate('/login')
                }}>
                <FiLogOut />
              </div>
            </div>
          )}
        </div>
      ) : (
        <>
          <div className='d-flex align-items-center justify-content-between mb-4'>
            <div className='sd-sidebar-toggle'>
              <a href='/'>
                <img
                  src='/icons/logo.svg'
                  alt='Logo'
                  style={{ width: '150px', height: '42px' }}
                  onClick={() => {
                    navigate('/')
                    if (isMobile) toggle()
                  }}
                />
              </a>
              <button
                onClick={toggle}
                className='btn p-0 border-0 bg-transparent mt-2'>
                <img
                  src='/icons/drower.svg'
                  alt='Drower'
                  style={{ width: '20px', height: '20px' }}
                />
              </button>
            </div>
          </div>

          {!isHomePage && (
            <SDButton
              variant='primary'
              label='Новый проект'
              iconLeft={<span>+</span>}
              className='text-blue mb-3'
              onClick={() => {
                navigate('/')
                if (isMobile) toggle()
              }}
            />
          )}

          <hr className='w-100' />
          <div
            className='d-flex align-items-center gap-2 mb-3 mx-3 '
            style={{ cursor: 'pointer' }}>
            <FaClockRotateLeft size={14} title='История' />
            <h4 className='sd-sidebar-history'>История</h4>
          </div>

          <div className='flex-grow-1 overflow-auto w-100'>
            {todayItems && todayItems.length > 0 && (
              <>
                <p className='sd-sidebar-day'>Сегодня</p>
                {todayItems?.map(item => (
                  <div
                    key={item.id}
                    className='sd-sidebar-text text-truncate'
                    onMouseEnter={() => setHoveredId(item.id)}
                    onMouseLeave={() => {
                      setHoveredId(null)
                      setMenuOpenId(null)
                    }}>
                    <span onClick={() => navigate(`/history/${item.id}`)}>
                      {item.title.length > 11
                        ? `${item.title.slice(0, 11)}...`
                        : item.title}
                    </span>

                    {hoveredId === item.id && menuOpenId !== item.id && (
                      <div
                        onClick={e => {
                          e.stopPropagation()
                          setMenuOpenId(item.id)
                        }}
                        style={{ marginLeft: 'auto', cursor: 'pointer' }}
                        className='ms-2'>
                        <HiDotsVertical />
                      </div>
                    )}

                    {menuOpenId === item.id && (
                      <FiTrash2
                        size={16}
                        className='text-danger ms-2'
                        style={{ cursor: 'pointer' }}
                        onClick={e => {
                          e.stopPropagation()
                          deleteItem(item.id)
                        }}
                      />
                    )}
                  </div>
                ))}
              </>
            )}

            {yesterdayItems && yesterdayItems.length > 0 && (
              <>
                <p className='sd-sidebar-day mt-3'>Вчера</p>
                {yesterdayItems?.map(item => (
                  <div
                    key={item.id}
                    className='sd-sidebar-text text-truncate'
                    onMouseEnter={() => setHoveredId(item.id)}
                    onMouseLeave={() => setHoveredId(null)}>
                    <span onClick={() => navigate(`/history/${item.id}`)}>
                      {item.title.length > 11
                        ? `${item.title.slice(0, 11)}...`
                        : item.title}
                    </span>

                    {hoveredId === item.id && menuOpenId !== item.id && (
                      <div
                        onClick={e => {
                          e.stopPropagation()
                          setMenuOpenId(item.id)
                        }}
                        style={{ marginLeft: 'auto', cursor: 'pointer' }}
                        className='ms-2'>
                        <HiDotsVertical />
                      </div>
                    )}

                    {menuOpenId === item.id && (
                      <FiTrash2
                        size={16}
                        className='text-danger ms-2'
                        style={{ cursor: 'pointer' }}
                        onClick={e => {
                          e.stopPropagation()
                          deleteItem(item.id)
                        }}
                      />
                    )}
                  </div>
                ))}
              </>
            )}
          </div>

          <div
            className='mt-auto pt-3 border-top position-relative'
            ref={dropdownRef}
            style={{
              marginTop: '15rem',
            }}>
            <div
              className='d-flex align-items-center mt-3'
              style={{ cursor: 'pointer' }}
              onClick={() => setDropdownOpen(!dropdownOpen)}>
              <div
                className='rounded-circle bg-secondary d-flex align-items-center justify-content-center me-2'
                style={{ width: 32, height: 32 }}>
                <FiUser size={18} className='text-white' />
              </div>
              <span className='fa-sidebar-footer'>Мой профиль</span>
            </div>

            {dropdownOpen && (
              <div
                className='position-absolute rounded p-2'
                style={{
                  bottom: '100%',
                  right: 0,
                  zIndex: 1000,
                  minWidth: '100%',
                  backgroundColor: 'white',
                }}>
                {/*  <div
                  className='dropdown-item py-1 px-2 text-dark dropdown-item'
                  style={{
                    cursor: 'pointer',
                  }}
                  onClick={() => console.log('Профиль')}>
                  Профиль
                </div> */}
                <div
                  className='dropdown-item py-1 px-2 text-dark'
                  style={{ cursor: 'pointer' }}
                  onClick={() => {
                    clearAuth()
                    navigate('/login')
                  }}>
                  Выйти
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}

export default Sidebar
