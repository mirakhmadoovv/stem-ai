import React from "react";

export const SidebarContext = React.createContext<{
  collapsed: boolean;
  setCollapsed: (val: boolean) => void;
}>({ collapsed: true, setCollapsed: () => {} });
