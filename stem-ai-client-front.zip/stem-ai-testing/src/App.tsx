import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import { Suspense, lazy } from 'react'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

import NoAuthLayout from './layouts/NoAuthLayout'
import AuthLayout from './layouts/AuthLayout'

const AuthPanel = lazy(() => import('./layouts/AuthPanel'))
const Home = lazy(() => import('./pages/HomePage'))
const Questions = lazy(() => import('./pages/Questions'))
const History = lazy(() => import('./pages/HistoryPage'))
const Payment = lazy(() => import('./pages/PaymentPage'))

function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: <AuthLayout />,
      children: [
        {
          path: '/',
          element: <Home />,
        },
        {
          path: 'category/:id',
          element: <Questions />,
        },
        {
          path: 'history/:id',
          element: <History />,
        },
        {
          path: 'payment',
          element: <Payment />,
        },
      ],
    },
    {
      path: '/',
      element: <NoAuthLayout />,
      children: [
        {
          path: 'login',
          element: <AuthPanel />,
        },
        {
          path: 'register',
          element: <AuthPanel />,
        },
      ],
    },
  ])

  return (
    <Suspense fallback={<div className='text-center p-5'>Loading...</div>}>
      <RouterProvider router={router} />
      <ToastContainer position='top-right' autoClose={3000} />
    </Suspense>
  )
}

export default App
