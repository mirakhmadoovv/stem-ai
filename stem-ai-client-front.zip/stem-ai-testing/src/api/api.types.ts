export interface Pagination {
  total: number
  per_page: number
  current_page: number
  last_page: number
  next_page_url: string | null
  prev_page_url: string | null
}

export interface ApiResponse<T> {
  data: T[]
  pagination: Pagination
}

// Category
export interface CategoryType {
  id: number
  parent_category: number | null
  image: string
  translations: { language_id: number; language_code: string; value: string }[]
  prompts: { language_id: number; language_code: string; prompt: string }[]
}

// Question Groups
export interface QuestionGroupTranslation {
  language_id: number
  language_code: string
  value: string
}

export interface QuestionGroup {
  id: number
  project: number
  order: number
  translations: QuestionGroupTranslation[]
}

export interface CategoryWithQuestionGroups {
  id: number
  parent_category: number | null
  image: string | null
  translations: QuestionGroupTranslation[]
  prompts: Array<{
    language_id: number
    prompt: string
    language_code: string
  }>
  question_groups: QuestionGroup[]
}

// Questions
export interface QuestionTranslation {
  language_id: number
  value: string
  language_code: string
}

export interface QuestionPrompt {
  language_id: number
  prompt: string
  language_code: string
}

export interface QuestionOptionTranslation {
  id: number
  language_id: number
  value: string
  bool: boolean
}

export interface QuestionOption {
  id: number
  translations: QuestionOptionTranslation[]
}

export interface Question {
  id: number
  group: number
  type: 'free_answer' | 'boolean' | 'select'
  prompts: QuestionPrompt[]
  translations: QuestionTranslation[]
  options: QuestionOption[]
}

export interface QuestionGroupWithQuestions {
  id: number
  project: number
  order: number
  translations: QuestionGroupTranslation[]
  questions: Question[]
  pagination: {
    total: number
    per_page: number
    current_page: number
    last_page: number
    next_page: string | null
    previous_page: string | null
  }
}

// Answer types for form submission
export interface QuestionAnswer {
  question_id: number
  answer_type: 'free_answer' | 'boolean' | 'select'
  answer_value?: string // for free_answer
  selected_options?: number[] // for boolean and select
}

// History
export interface Translation {
  language_id: number
  language_code: string
  value: string
}

export interface Prompt {
  language_id: number
  language_code: string
  prompt: string
}

export interface QuestionOption {
  id: number
  translations: QuestionOptionTranslation[]
  bool: boolean | null
}

export interface Question {
  id: number
  group: number
  type: 'boolean' | 'free_answer' | 'select'
  prompts: Prompt[]
  translations: Translation[]
  options: QuestionOption[]
}

export interface QuestionGroup {
  id: number
  project: number
  order: number
  translations: Translation[]
}

export interface QuestionReference {
  question_group: QuestionGroup
  question: Question
  options: number[]
  boolean_answer: boolean | null
}

export interface HistoryMessage {
  id: number
  model_name: string
  prompt_tokens: number
  completion_tokens: number
  total_tokens: number
  total_cost_usd: string
  response_text: string
  created_at: string
  questions: QuestionReference[]
}

export interface HistoryType {
  id: number
  title: string
  description: string | null
  message_count: number
  created_at: string
  messages: HistoryMessage[]
}

export interface HistoryListItem {
  id: number
  title: string
  description: string | null
  message_count: number
  created_at: string
}

export interface PaginatedResponse<T> {
  count: number
  next: string | null
  previous: string | null
  results: T[]
}
