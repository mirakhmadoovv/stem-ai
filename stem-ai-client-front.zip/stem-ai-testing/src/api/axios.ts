import axios from 'axios'
import type { LoginResponse, UserInfoResponse } from '../types/authTypes'

const API_URL = import.meta.env.VITE_API_BASE_URL

const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 100000,
})

// Ключи для хранения данных в localStorage
const AUTH_TOKEN_KEY = 'stem-auth-tokens'
const USER_INFO_KEY = 'stem-user-info'

// Типы для хранения токенов
interface StoredTokens {
  access: string
  refresh: string
}

/**
 * Получение токенов из localStorage
 */
export const getStoredTokens = (): StoredTokens | null => {
  const tokenString = localStorage.getItem(AUTH_TOKEN_KEY)
  if (!tokenString) return null
  try {
    return JSON.parse(tokenString)
  } catch {
    return null
  }
}

/**
 * Сохранение токенов в localStorage
 */
export const setStoredTokens = (tokens: StoredTokens): void => {
  localStorage.setItem(AUTH_TOKEN_KEY, JSON.stringify(tokens))
}

/**
 * Получение информации о пользователе из localStorage
 */
export const getStoredUserInfo = (): UserInfoResponse | null => {
  const userString = localStorage.getItem(USER_INFO_KEY)
  if (!userString) return null
  try {
    return JSON.parse(userString)
  } catch {
    return null
  }
}

/**
 * Сохранение информации о пользователе в localStorage
 */
export const setStoredUserInfo = (user: UserInfoResponse): void => {
  localStorage.setItem(USER_INFO_KEY, JSON.stringify(user))
}

/**
 * Очистка данных аутентификации
 */
export const clearAuth = (): void => {
  localStorage.removeItem(AUTH_TOKEN_KEY)
  localStorage.removeItem(USER_INFO_KEY)
}

// Очередь запросов, ожидающих обновления токена
let isRefreshing = false
let failedQueue: Array<{
  resolve: (value: string | PromiseLike<string>) => void
  reject: (reason?: unknown) => void
}> = []

/**
 * Обработка очереди запросов после обновления токена
 */
const processQueue = (error: unknown, token: string | null = null): void => {
  failedQueue.forEach(prom => {
    if (error) {
      prom.reject(error)
    } else {
      prom.resolve(token as string)
    }
  })
  failedQueue = []
}

/**
 * Настройка интерцепторов для API клиента
 */
// Добавление токена к запросам
apiClient.interceptors.request.use(
  config => {
    const tokens = getStoredTokens()
    if (tokens?.access) {
      config.headers.Authorization = `Bearer ${tokens.access}`
    }
    return config
  },
  error => Promise.reject(error)
)

// Обработка ответов и обновление токена при необходимости
apiClient.interceptors.response.use(
  response => response,
  async error => {
    const originalRequest = error.config

    // Проверка если access token истек и не пытаемся повторно уже
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true

      const tokens = getStoredTokens()
      if (!tokens?.refresh) {
        clearAuth()
        window.location.href = '/login'
        return Promise.reject(error)
      }

      if (isRefreshing) {
        return new Promise<string>((resolve, reject) => {
          failedQueue.push({ resolve, reject })
        }).then(token => {
          originalRequest.headers.Authorization = `Bearer ${token}`
          return apiClient(originalRequest)
        })
      }

      isRefreshing = true

      try {
        // Используем правильный URL для обновления токена
        const response = await axios.post<LoginResponse>(
          `${API_URL}/auth/token/refresh/`,
          {
            refresh: tokens.refresh,
          }
        )

        const newAccess = response.data.access
        const newTokens = { ...tokens, access: newAccess }
        setStoredTokens(newTokens)

        apiClient.defaults.headers.common.Authorization = `Bearer ${newAccess}`
        processQueue(null, newAccess)

        return apiClient(originalRequest)
      } catch (err) {
        processQueue(err, null)
        clearAuth()
        window.location.href = '/login'
        return Promise.reject(err)
      } finally {
        isRefreshing = false
      }
    }

    return Promise.reject(error)
  }
)
export default apiClient
