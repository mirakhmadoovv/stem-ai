import apiClient from './axios'
import type { LanguagesResponse } from '../types/authTypes'

/**
 * Получение списка доступных языков
 * @returns Список языков с пагинацией
 */
export const getLanguages = async (): Promise<LanguagesResponse> => {
  const response = await apiClient.get<LanguagesResponse>('/languages/')
  return response.data
}

/**
 * Обновление языка
 * @param id ID языка
 * @param data Данные для обновления
 * @returns Обновленный язык
 */
// export const updateLanguage = async (id: number, data: Partial<LanguageType>) => {
//   const response = await apiClient.put(`/languages/${id}/`, data);
//   return response.data;
// };
