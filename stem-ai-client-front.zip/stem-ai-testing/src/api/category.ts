import type { ApiResponse, CategoryType } from './api.types'
import apiClient from './axios'

export interface MutationCategoryType {
  parent_category: number | null
  image: string
  translations: { language_id: number; language_code: string; value: string }[]
  prompts: { language_id: number; language_code: string; value: string }[]
}

export const getCategories = async (
  params: string
): Promise<ApiResponse<CategoryType>> => {
  const response = await apiClient.get(`/projects${params}`)
  return response.data
}
export const getCategoryById = async (id: number): Promise<CategoryType> => {
  const { data } = await apiClient.get(`/projects/${id}`)
  return data
}
