import type { ApiResponse, HistoryType } from './api.types'
import apiClient from './axios'

export const getHistory = async (): Promise<ApiResponse<HistoryType>> => {
  const response = await apiClient.get(`/chat`)
  return response.data
}

export const getHistoryById = async (id: number): Promise<HistoryType> => {
  const { data } = await apiClient.get(`/chat/${id}`)
  return data
}

export const deleteHistoryById = async (id: number): Promise<void> => {
  await apiClient.delete(`/chat/${id}/delete`)
}
