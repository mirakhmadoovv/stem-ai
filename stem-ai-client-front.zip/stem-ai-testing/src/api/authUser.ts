import apiClient from './axios'
import type {
  UserInfoResponse,
  RefreshTokenPayload,
  RefreshTokenResponse,
} from '../types/authTypes'

/**
 * Получение информации о текущем пользователе
 * @returns Информация о пользователе
 */
export const getUserInfo = async (): Promise<UserInfoResponse> => {
  const response = await apiClient.get<UserInfoResponse>('/auth/me/')
  return response.data
}

/**
 * Обновление токена доступа
 * @param data Токен обновления
 * @returns Новый токен доступа
 */
export const refreshToken = async (
  data: RefreshTokenPayload
): Promise<RefreshTokenResponse> => {
  const response = await apiClient.post<RefreshTokenResponse>(
    '/auth/token/refresh/',
    data
  )
  return response.data
}
