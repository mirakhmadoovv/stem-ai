import apiClient from "./axios";
import type { LoginPayload, LoginResponse } from "../types/authTypes";

/**
 * Авторизация пользователя
 * @param data Данные для входа (имя пользователя и пароль)
 * @returns Токены доступа и обновления
 */
export const loginUser = async (data: LoginPayload): Promise<LoginResponse> => {
  const response = await apiClient.post<LoginResponse>("/auth/login/", data);
  return response.data;
};
