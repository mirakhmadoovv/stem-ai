import apiClient from "./axios";
import type { RegisterPayload, RegisterResponse } from "../types/authTypes";

/**
 * Регистрация нового пользователя
 * @param data Данные для регистрации (имя пользователя, email, пароль, язык)
 * @returns Информация о созданном пользователе
 */
export const registerUser = async (
  data: RegisterPayload
): Promise<RegisterResponse> => {
  const response = await apiClient.post<RegisterResponse>(
    "/auth/register/",
    data
  );
  return response.data;
};
