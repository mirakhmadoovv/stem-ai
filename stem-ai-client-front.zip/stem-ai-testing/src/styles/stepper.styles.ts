import type { CSSProperties } from 'react'

export const stepperStyles = {
  // Основной контейнер степпера
  container: {
    display: 'flex',
    flexDirection: 'column' as const,
    justifyContent: 'center',
    padding: '0px 0px 28px',
    width: '300px',
  } as CSSProperties,

  // Контейнер шага
  step: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '12px 20px',
    width: '100%',
    borderRadius: '5px',
  } as CSSProperties,

  // Активный шаг (с фоновой подсветкой)
  stepActive: {
    backgroundColor: 'rgba(74, 131, 255, 0.16)',
    padding: '12px 20px 20px',
  } as CSSProperties,

  // Иконка шага (завершенного) - синяя с белой галочкой
  stepIconCompleted: {
    width: '24px',
    height: '24px',
    borderRadius: '100px',
    backgroundColor: '#4A83FF',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#FFFFFF',
  } as CSSProperties,

  // Иконка шага (активного) - синяя с белым номером
  stepIconActive: {
    width: '24px',
    height: '24px',
    borderRadius: '100px',
    backgroundColor: '#4A83FF',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#FFFFFF',
    padding: '0px 9px',
  } as CSSProperties,

  // Иконка шага (неактивного) - серая с черным номером
  stepIconDefault: {
    width: '24px',
    height: '24px',
    borderRadius: '100px',
    backgroundColor: 'rgba(133, 129, 158, 0.48)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#020207',
  } as CSSProperties,

  // Номер в иконке
  stepNumber: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '12px',
    lineHeight: '1.66',
    letterSpacing: '3.33%',
    textAlign: 'center' as const,
  } as CSSProperties,

  // Контент шага
  stepContent: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '8px',
    flex: 1,
  } as CSSProperties,

  // Контент активного шага (с увеличенным gap)
  stepContentActive: {
    gap: '20px',
    width: '335px',
  } as CSSProperties,

  // Заголовок шага
  stepTitle: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '16px',
    lineHeight: '1.3',
    color: '#85819E',
    margin: 0,
  } as CSSProperties,

  // Описание шага
  stepDescription: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '20px',
    lineHeight: '1.3',
    color: '#020207',
    margin: 0,
  } as CSSProperties,

  // Коннектор между шагами (активный/завершенный)
  connector: {
    width: '1px',
    height: '30px',
    backgroundColor: 'rgba(74, 131, 255, 0.4)',
    marginLeft: '32px',
    marginTop: '-29px',
    marginBottom: '0px',
  } as CSSProperties,

  // Коннектор неактивный
  connectorInactive: {
    backgroundColor: 'rgba(133, 129, 158, 0.48)',
  } as CSSProperties,

  // Кнопка скачивания для финального шага
  downloadButton: {
    display: 'flex',
    flexDirection: 'row' as const,
    justifyContent: 'center',
    alignItems: 'center',
    gap: '12px',
    padding: '8px 20px',
    width: '100%',
    height: 'auto',
    backgroundColor: '#4A83FF',
    borderRadius: '5px',
    border: 'none',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  } as CSSProperties,

  // Текст кнопки скачивания
  downloadButtonText: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '14px',
    lineHeight: '1.3',
    color: '#FFFFFF',
  } as CSSProperties,

  // Иконка в кнопке
  downloadIcon: {
    width: '20px',
    height: '20px',
    color: '#FFFFFF',
  } as CSSProperties,
}
