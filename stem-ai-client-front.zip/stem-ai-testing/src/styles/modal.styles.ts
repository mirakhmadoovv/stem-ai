import type { CSSProperties } from 'react'

export const modalStyles = {
  // Основные стили для модального окна
  overlay: {
    position: 'fixed' as const,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  } as CSSProperties,

  content: {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '24px',
    maxWidth: '800px',
    width: '90%',
    maxHeight: '80vh',
    overflowY: 'auto' as const,
    position: 'relative' as const,
    boxShadow: '0 10px 25px rgba(0, 0, 0, 0.15)',
  } as CSSProperties,

  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '24px',
    paddingBottom: '16px',
    borderBottom: '1px solid #e0e0e0',
  } as CSSProperties,

  title: {
    fontSize: '24px',
    fontWeight: '600',
    color: '#212121',
    margin: 0,
  } as CSSProperties,

  closeButton: {
    background: 'none',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#838997',
    padding: '4px 8px',
    borderRadius: '4px',
    transition: 'color 0.2s',
  } as CSSProperties,

  closeButtonHover: {
    color: '#212121',
  } as CSSProperties,

  // Стили для сетки подкатегорий
  subcategoriesGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
    gap: '16px',
    marginTop: '16px',
  } as CSSProperties,

  subcategoryCard: {
    cursor: 'pointer',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: '#e0e0e0',
    borderRadius: '8px',
    padding: '16px',
    transition: 'all 0.2s ease',
    backgroundColor: '#ffffff',
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'flex-start',
    gap: '12px',
    minHeight: '120px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  } as CSSProperties,

  subcategoryCardHover: {
    transform: 'translateY(-2px)',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    borderColor: '#667eea',
  } as CSSProperties,

  subcategoryImage: {
    width: '40px',
    height: '40px',
    objectFit: 'cover' as const,
    borderRadius: '50%',
    backgroundColor: '#f5f5f5',
  } as CSSProperties,

  subcategoryTitle: {
    fontSize: '16px',
    fontWeight: '500',
    color: '#212121',
    margin: 0,
    lineHeight: '1.4',
  } as CSSProperties,
}
