import type { CSSProperties } from 'react'

export const resultsPageStyles = {
  // Основной контейнер (занимает все доступное пространство)
  container: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '24px',
    width: '100%',
    minHeight: '100vh',
    padding: 0,
    margin: 0,
  } as CSSProperties,

  // Основной фрейм с результатами
  mainFrame: {
    display: 'flex',
    flexDirection: 'column' as const,
    justifyContent: 'center',
    width: '100%',
    gap: '24px',
  } as CSSProperties,

  // Контейнер с белым фоном
  contentFrame: {
    display: 'flex',
    flexDirection: 'column' as const,
    justifyContent: 'center',
    width: '100%',
    gap: '40px',
    padding: '28px',
    backgroundColor: '#FFFFFF',
    borderRadius: '5px',
  } as CSSProperties,

  // Заголовок секции
  headerFrame: {
    display: 'flex',
    flexDirection: 'column' as const,
    width: '100%',
    gap: '16px',
  } as CSSProperties,

  // Стиль для "5 шаг"
  stepTitle: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '20px',
    lineHeight: '1.3',
    color: '#85819E',
    margin: 0,
  } as CSSProperties,

  // Основной заголовок
  mainTitle: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '36px',
    lineHeight: '1.3',
    color: '#020207',
    margin: 0,
  } as CSSProperties,

  // Контейнер для текста результата
  resultFrame: {
    display: 'flex',
    flexDirection: 'column' as const,
    width: '100%',
    gap: '40px',
  } as CSSProperties,

  // Основной текст результата
  resultText: {
    fontFamily: 'Rubik, sans-serif',
    fontWeight: '400',
    fontSize: '24px',
    lineHeight: '1.3',
    color: '#020207',
    width: '100%',
    whiteSpace: 'pre-wrap' as const,
  } as CSSProperties,

  // Контейнер для секций с подзаголовками
  sectionFrame: {
    display: 'flex',
    flexDirection: 'column' as const,
    width: '100%',
    gap: '16px',
  } as CSSProperties,

  // Подзаголовок секции
  sectionTitle: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '28px',
    lineHeight: '1.3',
    color: '#020207',
    width: '100%',
  } as CSSProperties,

  // Текст секции
  sectionText: {
    fontFamily: 'Rubik, sans-serif',
    fontWeight: '400',
    fontSize: '24px',
    lineHeight: '1.3',
    color: '#020207',
    width: '100%',
    whiteSpace: 'pre-wrap' as const,
  } as CSSProperties,

  // Дата создания
  dateText: {
    fontFamily: 'Rubik, sans-serif',
    fontWeight: '400',
    fontSize: '20px',
    lineHeight: '1.3',
    color: '#85819E',
    width: '100%',
  } as CSSProperties,

  // Кнопка скачивания
  downloadButton: {
    display: 'flex',
    flexDirection: 'row' as const,
    justifyContent: 'center',
    alignItems: 'center',
    gap: '12px',
    padding: '8px 20px',
    width: '200px',
    height: '40px',
    backgroundColor: '#4A83FF',
    borderRadius: '5px',
    border: 'none',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  } as CSSProperties,

  // Текст кнопки
  buttonText: {
    fontFamily: 'Bounded, sans-serif',
    fontWeight: '400',
    fontSize: '14px',
    lineHeight: '1.3',
    color: '#FFFFFF',
  } as CSSProperties,

  // Иконка
  iconStyle: {
    width: '20px',
    height: '20px',
    color: '#FFFFFF',
  } as CSSProperties,
}
